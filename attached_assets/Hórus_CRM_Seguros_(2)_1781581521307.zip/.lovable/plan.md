## Visão geral

Migrar o CRM de localStorage para Lovable Cloud (Postgres + Auth + Storage), introduzir autenticação por email/senha com roles (`admin` e `user`), isolar dados por dono, adicionar módulo de Consórcios, e enriquecer os cards com modal de detalhes e upload de anexos.

## 1. Backend (Lovable Cloud)

Ativar Lovable Cloud e criar via migration:

**Tabelas (todas com `owner_id uuid references auth.users` e RLS)**
- `profiles` (id, nome, email, criado_em) — auto via trigger no signup
- `user_roles` (user_id, role enum `admin|user`) — separado, com `has_role()` security definer
- `clientes`, `apolices`, `oportunidades`, `sinistros`, `comissoes` — campos atuais + `owner_id`
- `consorcios` (id, cliente_id, administradora, bem, grupo, cota, valor_credito, prazo_meses, taxa_adm_pct, parcela, inicio, status enum `Ativo|Contemplado|Quitado|Cancelado|Atrasado`, owner_id)
- `anexos` (id, entidade `cliente|apolice|consorcio|sinistro`, entidade_id, nome, mime, tamanho, storage_path, owner_id, criado_em)

**Políticas RLS (padrão para todas as tabelas de negócio)**
- `SELECT/UPDATE/DELETE`: `owner_id = auth.uid() OR has_role(auth.uid(),'admin')`
- `INSERT`: `owner_id = auth.uid()` (admin pode setar qualquer owner)
- `user_roles`: só admin escreve; usuário lê o próprio

**Storage**
- Bucket privado `anexos`; políticas restringem leitura ao dono do anexo ou admin.

## 2. Auth e roteamento

- Página pública `/auth` (login + signup email/senha; primeiro usuário vira admin automaticamente via trigger ou seed manual).
- Mover todas as páginas atuais para `src/routes/_authenticated/` (layout gerenciado pela integração).
- Logout no header do AppShell; mostrar nome e badge da role.

## 3. Refatoração do store

- Substituir `src/lib/store.ts` (localStorage) por hooks TanStack Query + server functions (`*.functions.ts`) usando `requireSupabaseAuth` — RLS faz o filtro por dono automaticamente.
- Manter as actions (`addCliente`, etc.) com a mesma assinatura, agora chamando server fns.
- Remover seed estático; novo usuário começa com base vazia. Admin pode importar via CSV/JSON (já existe).

## 4. Módulo Consórcios

- Nova rota `/_authenticated/consorcios` espelhando a estrutura de Apólices.
- Item no sidebar do `AppShell`.
- Importação CSV/JSON análoga (mapeador novo em `src/lib/import.ts`).
- KPIs do Dashboard incluem total de consórcios ativos e contemplações do mês.

## 5. Modal de detalhes + anexos

- Componente `EntityDetailModal` reutilizável que mostra:
  - Dados completos do cliente (todos os campos + cidade, contatos).
  - Lista de **produtos contratados**: apólices + consórcios vinculados (com prêmio, vigência, status).
  - Sinistros e comissões relacionados.
  - Aba "Anexos" com upload (drag-drop), lista com download/excluir.
- Botão "Ver detalhes" em cada linha/card de Clientes, Apólices e Consórcios.
- Upload aceita `pdf, doc, docx, csv, xls, xlsx, jpg, jpeg, png` (validação client + server por mime/extensão e tamanho ≤ 20MB).

## 6. Painel do administrador

- Rota `/_authenticated/admin/usuarios` (visível só para admin).
- Lista todos os usuários, permite alterar role (`admin`/`user`) e ver contagem de registros por dono.
- Admin vê filtro extra "Dono" em cada listagem para inspecionar dados de outros usuários.

## 7. Detalhes técnicos

- Server functions em `src/lib/*.functions.ts`; admin client carregado dentro do handler via `await import('@/integrations/supabase/client.server')` apenas onde necessário (ex.: alterar role).
- Uploads passam por server function que valida tamanho/mime, grava no bucket e insere linha em `anexos`.
- Migrations idempotentes; grants explícitos para `authenticated` em todas as tabelas do schema `public`.
- Dashboard, listagens e modais usam `useSuspenseQuery` com loader via `ensureQueryData`.

## 8. Fora do escopo desta iteração

- Reset de senha por email (pode ser adicionado depois).
- Equipes/multi-tenant além do owner_id individual.
- Histórico de auditoria / logs de acesso.
