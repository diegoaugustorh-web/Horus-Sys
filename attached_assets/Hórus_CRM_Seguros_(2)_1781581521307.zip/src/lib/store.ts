import { useSyncExternalStore } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export type Cliente = {
  id: string;
  ownerId: string;
  nome: string;
  cpfCnpj: string;
  email: string;
  telefone: string;
  tipo: "PF" | "PJ";
  cidade: string;
  observacao?: string;
  criadoEm: string;
  // PF
  dataNascimento?: string;
  estadoCivil?: string;
  contatoRecado?: string;
  // Endereço
  cep?: string;
  endereco?: string;
  numero?: string;
  complemento?: string;
  // PJ
  razaoSocial?: string;
  nomeFantasia?: string;
  inscricaoEstadual?: string;
  inscricaoMunicipal?: string;
  telefoneComercial?: string;
  repNome?: string;
  repCpf?: string;
  repDataNascimento?: string;
  repTelefone?: string;
  // Produto contratado
  produtoId?: string;
  produtoCategoria?: "seguro" | "consorcio";
  produtoValorContratado?: number;
  produtoQtdParcelas?: number;
  produtoValorParcela?: number;
  produtoValorTotalParcelas?: number;
  produtoValorComissao?: number;
  produtoDataAssembleia?: string;
  produtoResultadoAssembleia?: string;
};

export type Produto = {
  id: string;
  categoria: "seguro" | "consorcio";
  tipoPessoa: "PF" | "PJ" | "AMBOS";
  nome: string;
  ativo: boolean;
};

export type RamoSeguro = "Auto" | "Vida" | "Residencial" | "Empresarial" | "Saúde" | "Viagem";
export type StatusApolice = "Vigente" | "A Renovar" | "Vencida" | "Cancelada";

export type Apolice = {
  id: string;
  ownerId: string;
  numero: string;
  clienteId: string;
  seguradora: string;
  ramo: RamoSeguro;
  premio: number;
  inicio: string;
  fim: string;
  status: StatusApolice;
  comissaoPct: number;
  observacao?: string;
};

export type EstagioPipeline = "Lead" | "Cotação" | "Proposta" | "Negociação" | "Ganho" | "Perdido";

export type Oportunidade = {
  id: string;
  ownerId: string;
  cliente: string;
  ramo: RamoSeguro;
  valorEstimado: number;
  estagio: EstagioPipeline;
  responsavel: string;
  criadoEm: string;
  observacao?: string;
};

export type StatusSinistro = "Aberto" | "Em Análise" | "Aprovado" | "Negado" | "Pago";

export type Sinistro = {
  id: string;
  ownerId: string;
  protocolo: string;
  apoliceId: string;
  dataOcorrencia: string;
  descricao: string;
  valorEstimado: number;
  status: StatusSinistro;
  abertoEm: string;
};

export type StatusComissao = "A Receber" | "Recebida" | "Atrasada";

export type Comissao = {
  id: string;
  ownerId: string;
  apoliceId: string;
  parcela: number;
  totalParcelas: number;
  valor: number;
  vencimento: string;
  status: StatusComissao;
};

export type StatusConsorcio = "Ativo" | "Contemplado" | "Quitado" | "Cancelado" | "Atrasado";

export type Consorcio = {
  id: string;
  ownerId: string;
  clienteId: string;
  administradora: string;
  bem: string;
  grupo: string;
  cota: string;
  valorCredito: number;
  prazoMeses: number;
  taxaAdmPct: number;
  parcela: number;
  inicio: string;
  status: StatusConsorcio;
  observacao?: string;
};

export type Anexo = {
  id: string;
  ownerId: string;
  entidade: "cliente" | "apolice" | "consorcio" | "sinistro";
  entidadeId: string;
  nome: string;
  mime: string;
  tamanho: number;
  storagePath: string;
  criadoEm: string;
};

export type Role = "admin" | "corretor" | "atendente";

export type AppState = {
  session: Session | null;
  userId: string | null;
  userEmail: string | null;
  role: Role | null;
  ready: boolean; // auth resolved
  loading: boolean; // data loading
  clientes: Cliente[];
  apolices: Apolice[];
  oportunidades: Oportunidade[];
  sinistros: Sinistro[];
  comissoes: Comissao[];
  consorcios: Consorcio[];
};

const empty = {
  clientes: [], apolices: [], oportunidades: [], sinistros: [], comissoes: [], consorcios: [],
};

let state: AppState = {
  session: null,
  userId: null,
  userEmail: null,
  role: null,
  ready: false,
  loading: false,
  ...empty,
};

const listeners = new Set<() => void>();
const subscribe = (l: () => void) => { listeners.add(l); return () => listeners.delete(l); };
const getSnapshot = () => state;
const emit = () => { state = { ...state }; listeners.forEach((l) => l()); };
const set = (patch: Partial<AppState>) => { state = { ...state, ...patch }; listeners.forEach((l) => l()); };

export const useStore = () => useSyncExternalStore(subscribe, getSnapshot, () => state);

// ============= MAPPERS =============
const mapCliente = (r: any): Cliente => ({
  id: r.id, ownerId: r.owner_id, nome: r.nome, cpfCnpj: r.cpf_cnpj ?? "",
  email: r.email ?? "", telefone: r.telefone ?? "", tipo: r.tipo, cidade: r.cidade ?? "",
  observacao: r.observacao ?? undefined, criadoEm: (r.criado_em ?? "").slice(0, 10),
  dataNascimento: r.data_nascimento ?? undefined,
  estadoCivil: r.estado_civil ?? undefined,
  contatoRecado: r.contato_recado ?? undefined,
  cep: r.cep ?? undefined, endereco: r.endereco ?? undefined,
  numero: r.numero ?? undefined, complemento: r.complemento ?? undefined,
  razaoSocial: r.razao_social ?? undefined, nomeFantasia: r.nome_fantasia ?? undefined,
  inscricaoEstadual: r.inscricao_estadual ?? undefined,
  inscricaoMunicipal: r.inscricao_municipal ?? undefined,
  telefoneComercial: r.telefone_comercial ?? undefined,
  repNome: r.rep_nome ?? undefined, repCpf: r.rep_cpf ?? undefined,
  repDataNascimento: r.rep_data_nascimento ?? undefined,
  repTelefone: r.rep_telefone ?? undefined,
  produtoId: r.produto_id ?? undefined,
  produtoCategoria: r.produto_categoria ?? undefined,
  produtoValorContratado: r.produto_valor_contratado != null ? Number(r.produto_valor_contratado) : undefined,
  produtoQtdParcelas: r.produto_qtd_parcelas != null ? Number(r.produto_qtd_parcelas) : undefined,
  produtoValorParcela: r.produto_valor_parcela != null ? Number(r.produto_valor_parcela) : undefined,
  produtoValorTotalParcelas: r.produto_valor_total_parcelas != null ? Number(r.produto_valor_total_parcelas) : undefined,
  produtoValorComissao: r.produto_valor_comissao != null ? Number(r.produto_valor_comissao) : undefined,
  produtoDataAssembleia: r.produto_data_assembleia ?? undefined,
  produtoResultadoAssembleia: r.produto_resultado_assembleia ?? undefined,
});
const mapApolice = (r: any): Apolice => ({
  id: r.id, ownerId: r.owner_id, numero: r.numero, clienteId: r.cliente_id ?? "",
  seguradora: r.seguradora ?? "", ramo: r.ramo, premio: Number(r.premio ?? 0),
  inicio: r.inicio ?? "", fim: r.fim ?? "", status: r.status, comissaoPct: Number(r.comissao_pct ?? 0),
  observacao: r.observacao ?? undefined,
});
const mapOportunidade = (r: any): Oportunidade => ({
  id: r.id, ownerId: r.owner_id, cliente: r.cliente, ramo: r.ramo,
  valorEstimado: Number(r.valor_estimado ?? 0), estagio: r.estagio,
  responsavel: r.responsavel ?? "", criadoEm: (r.criado_em ?? "").slice(0, 10),
  observacao: r.observacao ?? undefined,
});
const mapSinistro = (r: any): Sinistro => ({
  id: r.id, ownerId: r.owner_id, protocolo: r.protocolo, apoliceId: r.apolice_id ?? "",
  dataOcorrencia: r.data_ocorrencia ?? "", descricao: r.descricao ?? "",
  valorEstimado: Number(r.valor_estimado ?? 0), status: r.status, abertoEm: r.aberto_em ?? "",
});
const mapComissao = (r: any): Comissao => ({
  id: r.id, ownerId: r.owner_id, apoliceId: r.apolice_id ?? "", parcela: r.parcela,
  totalParcelas: r.total_parcelas, valor: Number(r.valor ?? 0),
  vencimento: r.vencimento ?? "", status: r.status,
});
const mapConsorcio = (r: any): Consorcio => ({
  id: r.id, ownerId: r.owner_id, clienteId: r.cliente_id ?? "",
  administradora: r.administradora ?? "", bem: r.bem ?? "", grupo: r.grupo ?? "", cota: r.cota ?? "",
  valorCredito: Number(r.valor_credito ?? 0), prazoMeses: r.prazo_meses ?? 0,
  taxaAdmPct: Number(r.taxa_adm_pct ?? 0), parcela: Number(r.parcela ?? 0),
  inicio: r.inicio ?? "", status: r.status, observacao: r.observacao ?? undefined,
});

// ============= DATA LOADING =============
let loadToken = 0;
export async function reloadAll() {
  if (!state.userId) { set({ ...empty, loading: false }); return; }
  const my = ++loadToken;
  set({ loading: true });
  const [c, a, o, s, k, co] = await Promise.all([
    supabase.from("clientes").select("*").order("criado_em", { ascending: false }),
    supabase.from("apolices").select("*").order("criado_em", { ascending: false }),
    supabase.from("oportunidades").select("*").order("criado_em", { ascending: false }),
    supabase.from("sinistros").select("*").order("criado_em", { ascending: false }),
    supabase.from("comissoes").select("*").order("vencimento", { ascending: true }),
    supabase.from("consorcios").select("*").order("criado_em", { ascending: false }),
  ]);
  if (my !== loadToken) return;
  set({
    clientes: (c.data ?? []).map(mapCliente),
    apolices: (a.data ?? []).map(mapApolice),
    oportunidades: (o.data ?? []).map(mapOportunidade),
    sinistros: (s.data ?? []).map(mapSinistro),
    comissoes: (k.data ?? []).map(mapComissao),
    consorcios: (co.data ?? []).map(mapConsorcio),
    loading: false,
  });
}

async function loadRole(uid: string): Promise<Role | null> {
  const { data } = await supabase.from("user_roles").select("role").eq("user_id", uid);
  if (!data || data.length === 0) return null;
  const roles = data.map((r: any) => r.role as string);
  if (roles.includes("admin")) return "admin";
  if (roles.includes("corretor") || roles.includes("user")) return "corretor"; // legado
  if (roles.includes("atendente")) return "atendente";
  return "corretor";
}

async function applySession(session: Session | null) {
  if (!session) {
    set({ session: null, userId: null, userEmail: null, role: null, ready: true, ...empty });
    return;
  }
  const role = await loadRole(session.user.id);
  set({
    session,
    userId: session.user.id,
    userEmail: session.user.email ?? null,
    role,
    ready: true,
  });
  reloadAll();
}

// init auth listeners (browser only)
if (typeof window !== "undefined") {
  supabase.auth.onAuthStateChange((_evt, sess) => { applySession(sess); });
  supabase.auth.getSession().then(({ data }) => applySession(data.session));
}

// ============= ACTIONS =============
const need = () => {
  if (!state.userId) throw new Error("Não autenticado");
  return state.userId;
};

export const actions = {
  async signIn(email: string, password: string) {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
  },
  async signUp(email: string, password: string, nome: string) {
    const redirect = `${window.location.origin}/`;
    const { error } = await supabase.auth.signUp({
      email, password,
      options: { emailRedirectTo: redirect, data: { nome } },
    });
    if (error) throw error;
  },
  async signOut() {
    await supabase.auth.signOut();
  },

  // CLIENTES
  async addCliente(c: Omit<Cliente, "id" | "criadoEm" | "ownerId">) {
    const uid = need();
    const { error } = await supabase.from("clientes").insert({
      owner_id: uid,
      nome: c.nome, cpf_cnpj: c.cpfCnpj, email: c.email,
      telefone: c.telefone, tipo: c.tipo, cidade: c.cidade, observacao: c.observacao,
      data_nascimento: c.dataNascimento || null,
      estado_civil: c.estadoCivil || null,
      contato_recado: c.contatoRecado || null,
      cep: c.cep || null, endereco: c.endereco || null,
      numero: c.numero || null, complemento: c.complemento || null,
      razao_social: c.razaoSocial || null, nome_fantasia: c.nomeFantasia || null,
      inscricao_estadual: c.inscricaoEstadual || null,
      inscricao_municipal: c.inscricaoMunicipal || null,
      telefone_comercial: c.telefoneComercial || null,
      rep_nome: c.repNome || null, rep_cpf: c.repCpf || null,
      rep_data_nascimento: c.repDataNascimento || null,
      rep_telefone: c.repTelefone || null,
      produto_id: c.produtoId || null,
      produto_categoria: c.produtoCategoria ?? null,
      produto_valor_contratado: c.produtoValorContratado ?? null,
      produto_qtd_parcelas: c.produtoQtdParcelas ?? null,
      produto_valor_parcela: c.produtoValorParcela ?? null,
      produto_valor_total_parcelas: c.produtoValorTotalParcelas ?? null,
      produto_valor_comissao: c.produtoValorComissao ?? null,
      produto_data_assembleia: c.produtoDataAssembleia || null,
      produto_resultado_assembleia: c.produtoResultadoAssembleia || null,
    } as any);
    if (error) throw error;
    await reloadAll();
  },
  async updateCliente(id: string, patch: Partial<Omit<Cliente, "id" | "ownerId" | "criadoEm">>) {
    const map: Record<string, string> = {
      nome: "nome", cpfCnpj: "cpf_cnpj", email: "email", telefone: "telefone",
      tipo: "tipo", cidade: "cidade", observacao: "observacao",
      dataNascimento: "data_nascimento", estadoCivil: "estado_civil",
      contatoRecado: "contato_recado",
      cep: "cep", endereco: "endereco", numero: "numero", complemento: "complemento",
      razaoSocial: "razao_social", nomeFantasia: "nome_fantasia",
      inscricaoEstadual: "inscricao_estadual", inscricaoMunicipal: "inscricao_municipal",
      telefoneComercial: "telefone_comercial",
      repNome: "rep_nome", repCpf: "rep_cpf",
      repDataNascimento: "rep_data_nascimento", repTelefone: "rep_telefone",
      produtoId: "produto_id", produtoCategoria: "produto_categoria",
      produtoValorContratado: "produto_valor_contratado",
      produtoQtdParcelas: "produto_qtd_parcelas",
      produtoValorParcela: "produto_valor_parcela",
      produtoValorTotalParcelas: "produto_valor_total_parcelas",
      produtoValorComissao: "produto_valor_comissao",
      produtoDataAssembleia: "produto_data_assembleia",
      produtoResultadoAssembleia: "produto_resultado_assembleia",
    };
    const upd: any = {};
    for (const [k, v] of Object.entries(patch)) {
      const col = map[k];
      if (!col) continue;
      upd[col] = v === "" ? null : v ?? null;
    }
    const { error } = await supabase.from("clientes").update(upd).eq("id", id);
    if (error) throw error;
    await reloadAll();
  },
  async removeCliente(id: string) {
    const { error } = await supabase.from("clientes").delete().eq("id", id);
    if (error) throw error;
    await reloadAll();
  },

  // APOLICES
  async addApolice(a: Omit<Apolice, "id" | "ownerId">) {
    const uid = need();
    const { error } = await supabase.from("apolices").insert({
      owner_id: uid, numero: a.numero, cliente_id: a.clienteId || null,
      seguradora: a.seguradora, ramo: a.ramo, premio: a.premio,
      inicio: a.inicio || null, fim: a.fim || null, status: a.status,
      comissao_pct: a.comissaoPct, observacao: a.observacao,
    });
    if (error) throw error;
    await reloadAll();
  },
  async updateApoliceStatus(id: string, status: StatusApolice) {
    const { error } = await supabase.from("apolices").update({ status }).eq("id", id);
    if (error) throw error;
    await reloadAll();
  },
  async removeApolice(id: string) {
    const { error } = await supabase.from("apolices").delete().eq("id", id);
    if (error) throw error;
    await reloadAll();
  },

  // OPORTUNIDADES
  async addOportunidade(o: Omit<Oportunidade, "id" | "criadoEm" | "ownerId">) {
    const uid = need();
    const { error } = await supabase.from("oportunidades").insert({
      owner_id: uid, cliente: o.cliente, ramo: o.ramo,
      valor_estimado: o.valorEstimado, estagio: o.estagio,
      responsavel: o.responsavel, observacao: o.observacao,
    });
    if (error) throw error;
    await reloadAll();
  },
  async moveOportunidade(id: string, estagio: EstagioPipeline) {
    const { error } = await supabase.from("oportunidades").update({ estagio }).eq("id", id);
    if (error) throw error;
    await reloadAll();
  },
  async removeOportunidade(id: string) {
    const { error } = await supabase.from("oportunidades").delete().eq("id", id);
    if (error) throw error;
    await reloadAll();
  },

  // SINISTROS
  async addSinistro(s: Omit<Sinistro, "id" | "abertoEm" | "ownerId">) {
    const uid = need();
    const { error } = await supabase.from("sinistros").insert({
      owner_id: uid, protocolo: s.protocolo, apolice_id: s.apoliceId || null,
      data_ocorrencia: s.dataOcorrencia || null, descricao: s.descricao,
      valor_estimado: s.valorEstimado, status: s.status,
    });
    if (error) throw error;
    await reloadAll();
  },
  async updateSinistroStatus(id: string, status: StatusSinistro) {
    const { error } = await supabase.from("sinistros").update({ status }).eq("id", id);
    if (error) throw error;
    await reloadAll();
  },
  async removeSinistro(id: string) {
    const { error } = await supabase.from("sinistros").delete().eq("id", id);
    if (error) throw error;
    await reloadAll();
  },

  // COMISSOES
  async updateComissaoStatus(id: string, status: StatusComissao) {
    const { error } = await supabase.from("comissoes").update({ status }).eq("id", id);
    if (error) throw error;
    await reloadAll();
  },

  // CONSORCIOS
  async addConsorcio(c: Omit<Consorcio, "id" | "ownerId">) {
    const uid = need();
    const { error } = await supabase.from("consorcios").insert({
      owner_id: uid, cliente_id: c.clienteId || null,
      administradora: c.administradora, bem: c.bem, grupo: c.grupo, cota: c.cota,
      valor_credito: c.valorCredito, prazo_meses: c.prazoMeses,
      taxa_adm_pct: c.taxaAdmPct, parcela: c.parcela,
      inicio: c.inicio || null, status: c.status, observacao: c.observacao,
    });
    if (error) throw error;
    await reloadAll();
  },
  async updateConsorcioStatus(id: string, status: StatusConsorcio) {
    const { error } = await supabase.from("consorcios").update({ status }).eq("id", id);
    if (error) throw error;
    await reloadAll();
  },
  async removeConsorcio(id: string) {
    const { error } = await supabase.from("consorcios").delete().eq("id", id);
    if (error) throw error;
    await reloadAll();
  },
};

// ============= ANEXOS =============
const ALLOWED_MIME = [
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "text/csv",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "image/jpeg", "image/png", "image/jpg",
];
const MAX_SIZE = 20 * 1024 * 1024;

export async function listAnexos(entidade: Anexo["entidade"], entidadeId: string): Promise<Anexo[]> {
  const { data, error } = await supabase
    .from("anexos").select("*")
    .eq("entidade", entidade).eq("entidade_id", entidadeId)
    .order("criado_em", { ascending: false });
  if (error) throw error;
  return (data ?? []).map((r: any) => ({
    id: r.id, ownerId: r.owner_id, entidade: r.entidade, entidadeId: r.entidade_id,
    nome: r.nome, mime: r.mime ?? "", tamanho: Number(r.tamanho ?? 0),
    storagePath: r.storage_path, criadoEm: r.criado_em,
  }));
}

export async function uploadAnexo(entidade: Anexo["entidade"], entidadeId: string, file: File): Promise<void> {
  const uid = need();
  if (file.size > MAX_SIZE) throw new Error("Arquivo excede 20MB");
  if (file.type && !ALLOWED_MIME.includes(file.type)) {
    const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
    if (!["pdf","doc","docx","csv","xls","xlsx","jpg","jpeg","png"].includes(ext))
      throw new Error("Tipo de arquivo não permitido");
  }
  const safe = file.name.replace(/[^\w.\-]/g, "_");
  const path = `${uid}/${entidade}/${entidadeId}/${Date.now()}_${safe}`;
  const up = await supabase.storage.from("anexos").upload(path, file, { contentType: file.type });
  if (up.error) throw up.error;
  const { error } = await supabase.from("anexos").insert({
    owner_id: uid, entidade, entidade_id: entidadeId,
    nome: file.name, mime: file.type, tamanho: file.size, storage_path: path,
  });
  if (error) throw error;
}

export async function downloadAnexo(a: Anexo): Promise<string> {
  const { data, error } = await supabase.storage.from("anexos")
    .createSignedUrl(a.storagePath, 60);
  if (error) throw error;
  return data.signedUrl;
}

export async function removeAnexo(a: Anexo): Promise<void> {
  await supabase.storage.from("anexos").remove([a.storagePath]);
  await supabase.from("anexos").delete().eq("id", a.id);
}

// ============= USERS (admin) =============
export type UserSummary = {
  id: string;
  email: string;
  nome: string;
  role: Role | null;
  criadoEm: string;
};

export async function listUsuarios(): Promise<UserSummary[]> {
  const [{ data: profs }, { data: roles }] = await Promise.all([
    supabase.from("profiles").select("*").order("criado_em", { ascending: false }),
    supabase.from("user_roles").select("user_id, role"),
  ]);
  const roleMap = new Map<string, Role>();
  (roles ?? []).forEach((r: any) => {
    const v = r.role as string;
    const normalized: Role = v === "admin" ? "admin" : v === "atendente" ? "atendente" : "corretor";
    const existing = roleMap.get(r.user_id);
    // prioridade: admin > corretor > atendente
    if (normalized === "admin") roleMap.set(r.user_id, "admin");
    else if (!existing) roleMap.set(r.user_id, normalized);
  });
  return (profs ?? []).map((p: any) => ({
    id: p.id, email: p.email ?? "", nome: p.nome ?? "",
    role: roleMap.get(p.id) ?? null,
    criadoEm: (p.criado_em ?? "").slice(0, 10),
  }));
}

export async function setUsuarioRole(userId: string, role: Role): Promise<void> {
  // delete all existing then insert new (simple, admin-only)
  await supabase.from("user_roles").delete().eq("user_id", userId);
  const { error } = await supabase.from("user_roles").insert({ user_id: userId, role });
  if (error) throw error;
}

// ============= PRODUTOS (catálogo) =============
export async function listProdutos(opts?: { categoria?: "seguro" | "consorcio"; tipoPessoa?: "PF" | "PJ" }): Promise<Produto[]> {
  let q = supabase.from("produtos").select("*").eq("ativo", true).order("nome");
  if (opts?.categoria) q = q.eq("categoria", opts.categoria);
  const { data, error } = await q;
  if (error) throw error;
  const rows: Produto[] = (data ?? []).map((r: any) => ({
    id: r.id, categoria: r.categoria, tipoPessoa: r.tipo_pessoa, nome: r.nome, ativo: r.ativo,
  }));
  if (opts?.tipoPessoa) {
    return rows.filter((p) => p.tipoPessoa === opts.tipoPessoa || p.tipoPessoa === "AMBOS");
  }
  return rows;
}

// ============= HELPERS =============
export const fmtBRL = (v: number) =>
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export const fmtDate = (iso: string) => {
  if (!iso) return "";
  const s = iso.slice(0, 10);
  const [y, m, d] = s.split("-");
  if (!y || !m || !d) return iso;
  return `${d}/${m}/${y}`;
};

export const isAdmin = () => state.role === "admin";

// ============= PERMISSÕES =============
// Matriz de permissões por perfil.
//   admin     → tudo
//   corretor  → CRUD próprio em todos os módulos
//   atendente → CRUD em clientes e pipeline; somente leitura no resto
export type Permission =
  | "manage:seguros"   // criar/editar/excluir apólices, sinistros, consórcios, comissões
  | "delete:clientes"  // excluir clientes
  | "delete:pipeline"  // excluir oportunidades
  | "manage:usuarios"; // alterar perfis de outros usuários

export function can(role: Role | null, perm: Permission): boolean {
  if (!role) return false;
  if (role === "admin") return true;
  if (role === "corretor") return perm !== "manage:usuarios";
  // atendente
  return false;
}

export const usePerms = () => {
  const { role } = useStore();
  return {
    role,
    isAdmin: role === "admin",
    canManageSeguros: can(role, "manage:seguros"),
    canDeleteClientes: can(role, "delete:clientes"),
    canDeletePipeline: can(role, "delete:pipeline"),
    canManageUsuarios: can(role, "manage:usuarios"),
  };
};

export const ROLE_LABEL: Record<Role, string> = {
  admin: "Administrador",
  corretor: "Corretor",
  atendente: "Atendente",
};
