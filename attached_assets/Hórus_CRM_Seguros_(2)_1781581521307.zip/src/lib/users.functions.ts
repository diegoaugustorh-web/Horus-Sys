import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type Role = "admin" | "corretor" | "atendente";

type CreateInput = {
  email: string;
  nome: string;
  role: Role;
  mode: "invite" | "password";
  password?: string;
};

function validateCreate(raw: unknown): CreateInput {
  const o = (raw ?? {}) as Record<string, unknown>;
  const email = String(o.email ?? "").trim().toLowerCase();
  const nome = String(o.nome ?? "").trim().slice(0, 120);
  const role = String(o.role ?? "") as Role;
  const mode = String(o.mode ?? "invite") as "invite" | "password";
  const password = o.password ? String(o.password) : undefined;
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    throw new Error("E-mail inválido");
  }
  if (!nome) throw new Error("Nome obrigatório");
  if (!["admin", "corretor", "atendente"].includes(role)) {
    throw new Error("Perfil inválido");
  }
  if (mode === "password") {
    if (!password || password.length < 6 || password.length > 128) {
      throw new Error("Senha deve ter entre 6 e 128 caracteres");
    }
  }
  return { email, nome, role, mode, password };
}

async function assertAdmin(supabase: any, userId: string) {
  const { data, error } = await supabase.rpc("has_role", {
    _user_id: userId,
    _role: "admin",
  });
  if (error) throw new Error("Falha ao validar permissão");
  if (!data) throw new Error("Apenas administradores podem gerenciar usuários");
}

// Limites (janela = 1 hora):
//   create_user              → 10 por admin
//   invite (target email)    →  3 por e-mail
//   reset (target email)     →  3 por e-mail
//   reset (qualquer alvo)    → 30 por admin
//   delete_user              → 10 por admin
const RATE = {
  create_user: { window: "1 hour", limit: 10, scope: "admin" as const },
  invite_target: { window: "1 hour", limit: 3, scope: "target" as const },
  reset_target: { window: "1 hour", limit: 3, scope: "target" as const },
  reset_admin: { window: "1 hour", limit: 30, scope: "admin" as const },
  delete_user: { window: "1 hour", limit: 10, scope: "admin" as const },
};

async function enforceRateLimit(
  admin: any,
  adminId: string,
  action: keyof typeof RATE,
  target: string | null,
) {
  const cfg = RATE[action];
  const { data, error } = await admin.rpc("check_admin_rate_limit", {
    _admin: cfg.scope === "admin" ? adminId : null,
    _action: action,
    _target: cfg.scope === "target" ? target : null,
    _window: cfg.window,
    _limit: cfg.limit,
  });
  if (error) throw new Error("Falha ao validar limite de uso");
  if (data === false) {
    throw new Error(
      `Limite atingido (${cfg.limit}/${cfg.window}). Tente novamente mais tarde.`,
    );
  }
}

async function logAdminAction(
  admin: any,
  adminId: string,
  action: string,
  target: string | null,
) {
  await admin.from("admin_action_log").insert({
    admin_id: adminId,
    action,
    target,
  });
}

export const adminCheck = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId);
    return { ok: true as const };
  });

export const adminCreateUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(validateCreate)
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    await enforceRateLimit(supabaseAdmin, context.userId, "create_user", null);
    if (data.mode === "invite") {
      await enforceRateLimit(supabaseAdmin, context.userId, "invite_target", data.email);
    }

    let userId: string;
    if (data.mode === "invite") {
      const { data: res, error } = await supabaseAdmin.auth.admin.inviteUserByEmail(
        data.email,
        { data: { nome: data.nome } },
      );
      if (error || !res?.user) throw new Error(error?.message ?? "Falha ao convidar usuário");
      userId = res.user.id;
    } else {
      const { data: res, error } = await supabaseAdmin.auth.admin.createUser({
        email: data.email,
        password: data.password!,
        email_confirm: true,
        user_metadata: { nome: data.nome },
      });
      if (error || !res?.user) throw new Error(error?.message ?? "Falha ao criar usuário");
      userId = res.user.id;
    }

    await supabaseAdmin.from("profiles").upsert(
      { id: userId, nome: data.nome, email: data.email },
      { onConflict: "id" },
    );

    await supabaseAdmin.from("user_roles").delete().eq("user_id", userId);
    const { error: roleErr } = await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: userId, role: data.role });
    if (roleErr) throw new Error(roleErr.message);

    await logAdminAction(supabaseAdmin, context.userId, "create_user", data.email);
    if (data.mode === "invite") {
      await logAdminAction(supabaseAdmin, context.userId, "invite_target", data.email);
    }

    return { ok: true, userId };
  });

type ResetInput = { email: string };
function validateReset(raw: unknown): ResetInput {
  const email = String((raw as any)?.email ?? "").trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("E-mail inválido");
  return { email };
}

export const adminSendPasswordReset = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(validateReset)
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    await enforceRateLimit(supabaseAdmin, context.userId, "reset_admin", null);
    await enforceRateLimit(supabaseAdmin, context.userId, "reset_target", data.email);

    const { error } = await supabaseAdmin.auth.admin.generateLink({
      type: "recovery",
      email: data.email,
    });
    if (error) throw new Error(error.message);

    await logAdminAction(supabaseAdmin, context.userId, "reset_admin", data.email);
    await logAdminAction(supabaseAdmin, context.userId, "reset_target", data.email);

    return { ok: true };
  });

type DeleteInput = { userId: string };
function validateDelete(raw: unknown): DeleteInput {
  const userId = String((raw as any)?.userId ?? "");
  if (!/^[0-9a-f-]{36}$/i.test(userId)) throw new Error("ID inválido");
  return { userId };
}

export const adminDeleteUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(validateDelete)
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    if (data.userId === context.userId) throw new Error("Você não pode remover a si mesmo");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    await enforceRateLimit(supabaseAdmin, context.userId, "delete_user", null);

    const { error } = await supabaseAdmin.auth.admin.deleteUser(data.userId);
    if (error) throw new Error(error.message);

    await logAdminAction(supabaseAdmin, context.userId, "delete_user", data.userId);

    return { ok: true };
  });
