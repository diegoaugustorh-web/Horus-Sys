import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const recoverySchema = z.object({
  email: z.string().trim().email("E-mail inválido").max(254),
});

export const validateRecoveryEmail = createServerFn({ method: "POST" })
  .inputValidator((input) => recoverySchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: profile, error } = await supabaseAdmin
      .from("profiles")
      .select("id")
      .eq("email", data.email.toLowerCase())
      .maybeSingle();

    if (error) throw new Error("Não foi possível validar o e-mail agora");
    return { registered: Boolean(profile) };
  });