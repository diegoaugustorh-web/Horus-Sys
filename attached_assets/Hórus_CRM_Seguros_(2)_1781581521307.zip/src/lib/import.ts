import { actions, type AppState, type Cliente, type Apolice, type Oportunidade, type RamoSeguro, type StatusApolice, type EstagioPipeline } from "./store";

export type EntityKind = "clientes" | "apolices" | "pipeline";

// ---------- CSV parser (RFC 4180-ish, handles quotes and commas) ----------
export function parseCSV(text: string): Record<string, string>[] {
  const rows: string[][] = [];
  let cur: string[] = [];
  let field = "";
  let inQuotes = false;
  const src = text.replace(/\r\n?/g, "\n");
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (inQuotes) {
      if (ch === '"') {
        if (src[i + 1] === '"') { field += '"'; i++; }
        else inQuotes = false;
      } else field += ch;
    } else {
      if (ch === '"') inQuotes = true;
      else if (ch === ",") { cur.push(field); field = ""; }
      else if (ch === ";") { cur.push(field); field = ""; }
      else if (ch === "\n") { cur.push(field); rows.push(cur); cur = []; field = ""; }
      else field += ch;
    }
  }
  if (field.length || cur.length) { cur.push(field); rows.push(cur); }
  const cleaned = rows.filter((r) => r.some((c) => c.trim() !== ""));
  if (cleaned.length < 1) return [];
  const headers = cleaned[0].map((h) => h.trim().toLowerCase());
  return cleaned.slice(1).map((r) => {
    const obj: Record<string, string> = {};
    headers.forEach((h, i) => { obj[h] = (r[i] ?? "").trim(); });
    return obj;
  });
}

// ---------- Helpers ----------
const pick = (row: Record<string, string>, keys: string[]) => {
  for (const k of keys) {
    const v = row[k.toLowerCase()];
    if (v !== undefined && v !== "") return v;
  }
  return "";
};

const toNumber = (v: string): number => {
  if (!v) return 0;
  // Accept "1.234,56" or "1234.56" or "1234,56"
  const cleaned = v.replace(/[^\d,.-]/g, "");
  if (cleaned.includes(",") && cleaned.includes(".")) {
    return Number(cleaned.replace(/\./g, "").replace(",", ".")) || 0;
  }
  if (cleaned.includes(",")) return Number(cleaned.replace(",", ".")) || 0;
  return Number(cleaned) || 0;
};

const toISODate = (v: string): string => {
  if (!v) return "";
  const t = v.trim();
  // YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}/.test(t)) return t.slice(0, 10);
  // DD/MM/YYYY
  const m = t.match(/^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})/);
  if (m) {
    const [, d, mo, y] = m;
    const yy = y.length === 2 ? `20${y}` : y;
    return `${yy}-${mo.padStart(2, "0")}-${d.padStart(2, "0")}`;
  }
  const dt = new Date(t);
  if (!isNaN(dt.getTime())) return dt.toISOString().slice(0, 10);
  return "";
};

const RAMOS_VALID: RamoSeguro[] = ["Auto", "Vida", "Residencial", "Empresarial", "Saúde", "Viagem"];
const STATUS_AP: StatusApolice[] = ["Vigente", "A Renovar", "Vencida", "Cancelada"];
const ESTAGIOS: EstagioPipeline[] = ["Lead", "Cotação", "Proposta", "Negociação", "Ganho", "Perdido"];

const matchEnum = <T extends string>(v: string, list: T[], fallback: T): T => {
  const n = v.trim().toLowerCase();
  const found = list.find((x) => x.toLowerCase() === n || x.toLowerCase().replace(/\s|ç|ã|ó/g, (c) => ({ "ç": "c", "ã": "a", "ó": "o" }[c] || "")) === n.replace(/\s/g, ""));
  return (found as T) || fallback;
};

// ---------- Mappers ----------
export type ImportResult = { ok: number; skipped: number; errors: string[] };

export const mapClientes = (rows: Record<string, string>[], existing: AppState): Omit<Cliente, "id" | "criadoEm" | "ownerId">[] => {
  const existingKeys = new Set(existing.clientes.map((c) => `${c.cpfCnpj}|${c.email}`.toLowerCase()));
  const out: Omit<Cliente, "id" | "criadoEm" | "ownerId">[] = [];
  for (const r of rows) {
    const nome = pick(r, ["nome", "name", "cliente", "razao social", "razão social"]);
    if (!nome) continue;
    const cpfCnpj = pick(r, ["cpfcnpj", "cpf/cnpj", "cpf_cnpj", "documento", "cpf", "cnpj"]);
    const email = pick(r, ["email", "e-mail"]);
    const key = `${cpfCnpj}|${email}`.toLowerCase();
    if (existingKeys.has(key)) continue;
    existingKeys.add(key);
    const tipoRaw = pick(r, ["tipo", "type"]).toUpperCase();
    const tipo: "PF" | "PJ" = tipoRaw === "PJ" || cpfCnpj.replace(/\D/g, "").length === 14 ? "PJ" : "PF";
    out.push({
      nome,
      tipo,
      cpfCnpj,
      email,
      telefone: pick(r, ["telefone", "phone", "celular"]),
      cidade: pick(r, ["cidade", "city"]),
    });
  }
  return out;
};

export const mapApolices = (rows: Record<string, string>[], existing: AppState): Omit<Apolice, "id" | "ownerId">[] => {
  const numSet = new Set(existing.apolices.map((a) => a.numero.toLowerCase()));
  const out: Omit<Apolice, "id" | "ownerId">[] = [];
  for (const r of rows) {
    const numero = pick(r, ["numero", "número", "nº", "n", "policy", "apolice", "apólice"]);
    if (!numero) continue;
    if (numSet.has(numero.toLowerCase())) continue;
    numSet.add(numero.toLowerCase());
    const clienteRef = pick(r, ["cliente", "clienteid", "cliente_id", "segurado", "nome"]);
    const cli = existing.clientes.find((c) => c.id === clienteRef || c.nome.toLowerCase() === clienteRef.toLowerCase() || c.cpfCnpj === clienteRef);
    if (!cli) continue;
    out.push({
      numero,
      clienteId: cli.id,
      seguradora: pick(r, ["seguradora", "insurer"]) || "—",
      ramo: matchEnum(pick(r, ["ramo", "tipo", "produto"]), RAMOS_VALID, "Auto"),
      premio: toNumber(pick(r, ["premio", "prêmio", "valor", "premium"])),
      inicio: toISODate(pick(r, ["inicio", "início", "vigencia_inicio", "start", "data_inicio"])) || new Date().toISOString().slice(0, 10),
      fim: toISODate(pick(r, ["fim", "vigencia_fim", "end", "data_fim"])) || new Date(Date.now() + 365 * 86400000).toISOString().slice(0, 10),
      status: matchEnum(pick(r, ["status"]), STATUS_AP, "Vigente"),
      comissaoPct: toNumber(pick(r, ["comissao", "comissão", "comissaopct", "commission"])) || 15,
    });
  }
  return out;
};

export const mapPipeline = (rows: Record<string, string>[]): Omit<Oportunidade, "id" | "criadoEm" | "ownerId">[] => {
  const out: Omit<Oportunidade, "id" | "criadoEm" | "ownerId">[] = [];
  for (const r of rows) {
    const cliente = pick(r, ["cliente", "prospect", "nome", "lead"]);
    if (!cliente) continue;
    out.push({
      cliente,
      ramo: matchEnum(pick(r, ["ramo", "produto"]), RAMOS_VALID, "Auto"),
      valorEstimado: toNumber(pick(r, ["valor", "valorestimado", "valor_estimado", "value"])),
      estagio: matchEnum(pick(r, ["estagio", "estágio", "stage", "etapa"]), ESTAGIOS, "Lead"),
      responsavel: pick(r, ["responsavel", "responsável", "owner"]) || "—",
      observacao: pick(r, ["observacao", "observação", "notes"]),
    });
  }
  return out;
};

// ---------- Public API ----------
export function parseFile(text: string, filename: string): Record<string, string>[] {
  const isJSON = filename.toLowerCase().endsWith(".json") || text.trim().startsWith("[") || text.trim().startsWith("{");
  if (isJSON) {
    try {
      const data = JSON.parse(text);
      const arr = Array.isArray(data) ? data : Array.isArray(data?.data) ? data.data : [data];
      return arr.map((row: Record<string, unknown>) => {
        const o: Record<string, string> = {};
        for (const k in row) o[k.toLowerCase()] = String(row[k] ?? "");
        return o;
      });
    } catch {
      return [];
    }
  }
  return parseCSV(text);
}

export function runImport(kind: EntityKind, rows: Record<string, string>[], state: AppState): ImportResult {
  const errors: string[] = [];
  let ok = 0;
  if (kind === "clientes") {
    const mapped = mapClientes(rows, state);
    mapped.forEach((c) => { actions.addCliente(c); ok++; });
    return { ok, skipped: rows.length - ok, errors };
  }
  if (kind === "apolices") {
    const mapped = mapApolices(rows, state);
    mapped.forEach((a) => { actions.addApolice(a); ok++; });
    const skipped = rows.length - ok;
    if (skipped > 0) errors.push(`${skipped} linha(s) ignoradas (cliente não encontrado ou número duplicado).`);
    return { ok, skipped, errors };
  }
  const mapped = mapPipeline(rows);
  mapped.forEach((o) => { actions.addOportunidade(o); ok++; });
  return { ok, skipped: rows.length - ok, errors };
}

export const TEMPLATES: Record<EntityKind, { headers: string[]; sample: string[] }> = {
  clientes: {
    headers: ["nome", "tipo", "cpfCnpj", "email", "telefone", "cidade"],
    sample: ["João Silva", "PF", "111.222.333-44", "joao@email.com", "(11) 99999-0000", "São Paulo"],
  },
  apolices: {
    headers: ["numero", "cliente", "seguradora", "ramo", "premio", "inicio", "fim", "status", "comissaoPct"],
    sample: ["AP-2025-99999", "Marina Lopes", "Porto Seguro", "Auto", "3850", "2025-02-01", "2026-02-01", "Vigente", "15"],
  },
  pipeline: {
    headers: ["cliente", "ramo", "valorEstimado", "estagio", "responsavel", "observacao"],
    sample: ["André Carvalho", "Auto", "4200", "Lead", "Ana", "Indicação"],
  },
};

export const buildTemplateCSV = (kind: EntityKind): string => {
  const t = TEMPLATES[kind];
  return `${t.headers.join(",")}\n${t.sample.join(",")}\n`;
};
