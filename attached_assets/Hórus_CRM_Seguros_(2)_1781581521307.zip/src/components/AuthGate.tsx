import { useEffect, useState, type ReactNode } from "react";
import { useNavigate, useRouterState } from "@tanstack/react-router";
import { useStore } from "@/lib/store";

export function AuthGate({ children }: { children: ReactNode }) {
  const { ready, session, loading } = useStore();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const href = useRouterState({ select: (s) => s.location.href });

  // Avoid SSR/CSR hydration mismatch — auth state only resolves on the client.
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const isAuthRoute = pathname === "/auth" || pathname === "/reset-password";

  useEffect(() => {
    if (!mounted || !ready) return;
    if (!session && !isAuthRoute) {
      navigate({ to: "/auth", search: { redirect: href }, replace: true });
    }
  }, [mounted, ready, session, isAuthRoute, href, navigate]);

  // Pre-mount + auth still loading: render nothing stable (avoid hydration diff).
  if (!mounted || !ready) {
    return (
      <div suppressHydrationWarning className="min-h-screen flex items-center justify-center text-sm text-muted-foreground">
        {mounted ? "Carregando…" : ""}
      </div>
    );
  }

  // Public auth route — render regardless of session.
  if (isAuthRoute) return <>{children}</>;

  // Protected: wait until redirect kicks in.
  if (!session) return null;

  return (
    <>
      {loading && (
        <div className="fixed top-0 inset-x-0 h-0.5 bg-primary/60 animate-pulse z-50" />
      )}
      {children}
    </>
  );
}
