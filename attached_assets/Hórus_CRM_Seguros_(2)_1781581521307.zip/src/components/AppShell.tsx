import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { useStore, actions, ROLE_LABEL, usePerms } from "@/lib/store";

const baseNav = [
  { to: "/", label: "Dashboard", icon: "▦" },
  { to: "/clientes", label: "Clientes", icon: "◍" },
  { to: "/produtos", label: "Produtos", icon: "▣" },
  { to: "/pipeline", label: "Pipeline", icon: "❯" },
  { to: "/reunioes", label: "Reuniões", icon: "◫" },
  { to: "/comissoes", label: "Comissões", icon: "$" },
] as const;
const adminNav = [{ to: "/usuarios", label: "Usuários", icon: "◉" }] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const { isAdmin } = usePerms();
  const navItems = isAdmin ? [...baseNav, ...adminNav] : baseNav;
  return (
    <div className="min-h-screen flex bg-background">
      <aside className="hidden lg:flex w-64 shrink-0 flex-col border-r border-sidebar-border bg-sidebar">
        <div className="px-6 py-5 border-b border-sidebar-border">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-md bg-primary text-primary-foreground flex items-center justify-center font-bold tracking-tight">
              H
            </div>
            <div>
              <div className="text-sm font-semibold text-foreground leading-tight">Hórus</div>
              <div className="text-[11px] text-muted-foreground leading-tight">CRM de Seguros</div>
            </div>
          </Link>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-0.5">
          {navItems.map((it) => (
            <Link
              key={it.to}
              to={it.to}
              activeOptions={{ exact: it.to === "/" }}
              activeProps={{ className: "bg-sidebar-accent text-sidebar-accent-foreground font-medium" }}
              inactiveProps={{ className: "text-sidebar-foreground hover:bg-sidebar-accent/60" }}
              className="flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors"
            >
              <span className="w-5 text-center text-muted-foreground">{it.icon}</span>
              <span>{it.label}</span>
            </Link>
          ))}
        </nav>
        <div className="px-4 py-3 border-t border-sidebar-border text-[11px] text-muted-foreground">
          v1.0 · ambiente demo
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="border-b border-border bg-card px-4 lg:px-6 py-2.5 flex items-center justify-between gap-3">
          <Link to="/" className="flex items-center gap-2 lg:hidden">
            <div className="w-8 h-8 rounded-md bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">H</div>
            <span className="font-semibold">Hórus</span>
          </Link>
          <div className="hidden lg:block" />
          <UserMenu />
        </header>
        <nav className="lg:hidden overflow-x-auto border-b border-border bg-card">
          <div className="flex gap-1 px-3 py-2 min-w-max">
            {navItems.map((it) => (
              <Link
                key={it.to}
                to={it.to}
                activeOptions={{ exact: it.to === "/" }}
                activeProps={{ className: "bg-sidebar-accent text-sidebar-accent-foreground" }}
                inactiveProps={{ className: "text-muted-foreground" }}
                className="px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap"
              >
                {it.label}
              </Link>
            ))}
          </div>
        </nav>
        <main className="flex-1 min-w-0">{children}</main>
      </div>
    </div>
  );
}

function UserMenu() {
  const { userEmail, role } = useStore();
  if (!userEmail) return null;
  const initials = userEmail.slice(0, 2).toUpperCase();
  return (
    <div className="flex items-center gap-3">
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-semibold">
          {initials}
        </div>
        <div className="hidden sm:block leading-tight">
          <div className="text-xs font-medium text-foreground">{userEmail}</div>
          <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
            {role ? ROLE_LABEL[role] : "—"}
          </div>
        </div>
      </div>
      <Button size="sm" variant="secondary" onClick={() => actions.signOut()}>
        Sair
      </Button>
    </div>
  );
}

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 mb-6 flex-wrap">
      <div>
        <h1 className="text-2xl font-semibold text-foreground tracking-tight">{title}</h1>
        {subtitle && <p className="text-sm text-muted-foreground mt-1">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className={`bg-card rounded-lg border border-border shadow-card ${className}`}>{children}</div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    Vigente: "bg-success/10 text-success border-success/20",
    "A Renovar": "bg-warning/15 text-warning-foreground border-warning/30",
    Vencida: "bg-destructive/10 text-destructive border-destructive/20",
    Cancelada: "bg-muted text-muted-foreground border-border",
    Aberto: "bg-info/10 text-info border-info/20",
    "Em Análise": "bg-warning/15 text-warning-foreground border-warning/30",
    Aprovado: "bg-success/10 text-success border-success/20",
    Negado: "bg-destructive/10 text-destructive border-destructive/20",
    Pago: "bg-primary/10 text-primary border-primary/20",
    "A Receber": "bg-info/10 text-info border-info/20",
    Recebida: "bg-success/10 text-success border-success/20",
    Atrasada: "bg-destructive/10 text-destructive border-destructive/20",
  };
  const cls = map[status] || "bg-muted text-muted-foreground border-border";
  return <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${cls}`}>{status}</span>;
}

export function Button({
  children,
  variant = "primary",
  size = "md",
  className = "",
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" | "ghost" | "danger"; size?: "sm" | "md" }) {
  const variants = {
    primary: "bg-primary text-primary-foreground hover:bg-primary/90",
    secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80 border border-border",
    ghost: "text-foreground hover:bg-muted",
    danger: "text-destructive hover:bg-destructive/10",
  };
  const sizes = { sm: "h-8 px-3 text-xs", md: "h-9 px-4 text-sm" };
  return (
    <button
      className={`inline-flex items-center justify-center gap-1.5 rounded-md font-medium transition-colors disabled:opacity-50 disabled:pointer-events-none ${variants[variant]} ${sizes[size]} ${className}`}
      {...rest}
    >
      {children}
    </button>
  );
}

export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={`h-9 w-full rounded-md border border-input bg-background px-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/40 focus:border-ring ${props.className || ""}`}
    />
  );
}

export function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={`h-9 w-full rounded-md border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 focus:border-ring ${props.className || ""}`}
    />
  );
}

export function Textarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={`w-full rounded-md border border-input bg-background px-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/40 focus:border-ring ${props.className || ""}`}
    />
  );
}

export function Label({ children }: { children: ReactNode }) {
  return <label className="text-xs font-medium text-foreground mb-1.5 block">{children}</label>;
}

export function Modal({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-foreground/40" onClick={onClose}>
      <div className="bg-card rounded-lg shadow-elevated border border-border w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="px-5 py-4 border-b border-border flex items-center justify-between">
          <h2 className="font-semibold text-foreground">{title}</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground text-xl leading-none">×</button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}
