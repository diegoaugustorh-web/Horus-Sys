import { useRef, useState } from "react";
import { Button, Modal, Label } from "./AppShell";
import { useStore } from "@/lib/store";
import { parseFile, runImport, buildTemplateCSV, TEMPLATES, type EntityKind, type ImportResult } from "@/lib/import";

const LABELS: Record<EntityKind, string> = {
  clientes: "clientes",
  apolices: "apólices",
  pipeline: "oportunidades",
};

export function ImportModal({ open, onClose, kind }: { open: boolean; onClose: () => void; kind: EntityKind }) {
  const state = useStore();
  const fileRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<Record<string, string>[] | null>(null);
  const [filename, setFilename] = useState("");
  const [result, setResult] = useState<ImportResult | null>(null);

  const onFile = async (f: File) => {
    setFilename(f.name);
    const text = await f.text();
    const rows = parseFile(text, f.name);
    setPreview(rows);
    setResult(null);
  };

  const doImport = () => {
    if (!preview) return;
    const r = runImport(kind, preview, state);
    setResult(r);
    setPreview(null);
  };

  const downloadTemplate = () => {
    const csv = buildTemplateCSV(kind);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `template-${kind}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const close = () => { setPreview(null); setResult(null); setFilename(""); onClose(); };

  const template = TEMPLATES[kind];

  return (
    <Modal open={open} onClose={close} title={`Importar ${LABELS[kind]}`}>
      <div className="space-y-4">
        <div className="text-sm text-muted-foreground">
          Envie um arquivo <strong>CSV</strong> ou <strong>JSON</strong> com as colunas esperadas.
          Os dados serão adicionados ao CRM (duplicados são ignorados).
        </div>

        <div className="bg-muted/40 rounded-md p-3 text-xs">
          <div className="font-medium text-foreground mb-1">Colunas esperadas:</div>
          <code className="text-[11px] text-muted-foreground break-all">{template.headers.join(", ")}</code>
          <button onClick={downloadTemplate} className="block mt-2 text-primary hover:underline text-xs font-medium">
            ↓ Baixar template CSV
          </button>
        </div>

        {!result && (
          <>
            <div>
              <Label>Arquivo (.csv ou .json)</Label>
              <input
                ref={fileRef}
                type="file"
                accept=".csv,.json,text/csv,application/json"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); }}
                className="block w-full text-sm file:mr-3 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:bg-primary file:text-primary-foreground file:text-xs file:font-medium hover:file:bg-primary/90 file:cursor-pointer"
              />
            </div>

            {preview && (
              <div className="border border-border rounded-md overflow-hidden">
                <div className="px-3 py-2 bg-muted/40 text-xs flex justify-between items-center">
                  <span><strong>{filename}</strong> · {preview.length} linha(s)</span>
                </div>
                <div className="max-h-48 overflow-auto">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/20 sticky top-0">
                      <tr>
                        {Object.keys(preview[0] || {}).slice(0, 5).map((h) => (
                          <th key={h} className="px-2 py-1.5 text-left font-medium text-muted-foreground">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {preview.slice(0, 5).map((r, i) => (
                        <tr key={i} className="border-t border-border/50">
                          {Object.keys(preview[0] || {}).slice(0, 5).map((h) => (
                            <td key={h} className="px-2 py-1.5 truncate max-w-[140px]">{r[h]}</td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {preview.length > 5 && <div className="px-3 py-1.5 text-[11px] text-muted-foreground bg-muted/20 border-t border-border">+ {preview.length - 5} linha(s) adicional(is)…</div>}
              </div>
            )}
          </>
        )}

        {result && (
          <div className="rounded-md border border-success/30 bg-success/10 p-4 text-sm">
            <div className="font-medium text-foreground">✓ Importação concluída</div>
            <div className="text-muted-foreground mt-1">
              {result.ok} registro(s) adicionado(s){result.skipped > 0 && ` · ${result.skipped} ignorado(s)`}.
            </div>
            {result.errors.map((e, i) => (
              <div key={i} className="text-xs text-warning-foreground mt-1">{e}</div>
            ))}
          </div>
        )}

        <div className="flex justify-end gap-2 pt-2">
          <Button variant="secondary" onClick={close}>Fechar</Button>
          {!result && <Button onClick={doImport} disabled={!preview || preview.length === 0}>Importar {preview ? `(${preview.length})` : ""}</Button>}
        </div>
      </div>
    </Modal>
  );
}
