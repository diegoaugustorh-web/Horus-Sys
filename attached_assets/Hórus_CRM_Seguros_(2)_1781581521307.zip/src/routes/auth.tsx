import { createFileRoute, useRouter, useSearch } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { Eye, EyeOff, LockKeyhole, Mail } from "lucide-react";
import { useStore, actions } from "@/lib/store";
import { supabase } from "@/integrations/supabase/client";
import { validateRecoveryEmail } from "@/lib/auth.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import logoAsset from "@/assets/horus-logo-new.jpg.asset.json";

// Accept only same-origin relative paths. Reject absolute URLs, protocol-relative
// and the /auth route itself to avoid open-redirect loops.
function sanitizeRedirect(raw: unknown): string {
  if (typeof raw !== "string" || raw.length === 0) return "/";
  if (!raw.startsWith("/") || raw.startsWith("//")) return "/";
  if (raw === "/auth" || raw.startsWith("/auth?") || raw.startsWith("/auth#")) return "/";
  return raw;
}

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>) => ({
    redirect: sanitizeRedirect(s.redirect),
  }),
  component: AuthPage,
  head: () => ({
    meta: [
      { title: "Entrar — Hórus CRM" },
      { name: "description", content: "Acesse sua conta do Hórus CRM de Seguros." },
    ],
  }),
});

function AuthPage() {
  const { session, ready } = useStore();
  const router = useRouter();
  const { redirect } = useSearch({ from: "/auth" });

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [recoveryOpen, setRecoveryOpen] = useState(false);
  const [recoveryEmail, setRecoveryEmail] = useState("");
  const [recoveryBusy, setRecoveryBusy] = useState(false);
  const [recoveryError, setRecoveryError] = useState<string | null>(null);
  const [recoveryInfo, setRecoveryInfo] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const checkRecoveryEmail = useServerFn(validateRecoveryEmail);

  // Already signed in → bounce to original URL (preserves path + query + hash).
  useEffect(() => {
    if (ready && session) {
      router.history.replace(redirect);
    }
  }, [ready, session, redirect, router]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    setBusy(true);
    try {
      await actions.signIn(email.trim().toLowerCase(), password);
    } catch (e: any) {
      setErr(e?.message === "Invalid login credentials" ? "E-mail ou senha incorretos." : "Não foi possível entrar. Tente novamente.");
    } finally {
      setBusy(false);
    }
  };

  const requestRecovery = async (event: React.FormEvent) => {
    event.preventDefault();
    setRecoveryError(null);
    setRecoveryInfo(null);
    setRecoveryBusy(true);
    const normalizedEmail = recoveryEmail.trim().toLowerCase();
    try {
      const result = await checkRecoveryEmail({ data: { email: normalizedEmail } });
      if (!result.registered) {
        setRecoveryError("E-mail não encontrado. Verifique o endereço informado.");
        return;
      }
      const { error } = await supabase.auth.resetPasswordForEmail(normalizedEmail, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) throw error;
      setRecoveryInfo("Link enviado. Verifique sua caixa de entrada e o spam.");
    } catch {
      setRecoveryError("Não foi possível enviar o link agora. Tente novamente.");
    } finally {
      setRecoveryBusy(false);
    }
  };

  return (
    <main className="min-h-screen bg-muted/30 px-4 py-8 flex items-center justify-center">
      <div className="w-full max-w-md">
        <img src={logoAsset.url} alt="Hórus" className="mx-auto mb-5 w-full max-w-[330px] rounded-xl object-contain bg-white p-4 shadow-card" />
        <section className="rounded-xl border border-border bg-card p-6 shadow-elevated">
          <div className="mb-5 text-center">
            <h1 className="text-xl font-semibold tracking-tight">Acesse sua conta</h1>
          </div>
          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="email">E-mail</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-2.5 size-4 text-muted-foreground" />
                <Input id="email" type="email" required maxLength={254} autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className="pl-9" placeholder="nome@empresa.com.br" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">Senha</Label>
              <div className="relative">
                <LockKeyhole className="absolute left-3 top-2.5 size-4 text-muted-foreground" />
                <Input id="password" type={showPassword ? "text" : "password"} required minLength={6} maxLength={128} autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} className="px-9" />
                <Button type="button" variant="ghost" size="icon" aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"} onClick={() => setShowPassword((value) => !value)} className="absolute right-0 top-0 shadow-none">
                  {showPassword ? <EyeOff /> : <Eye />}
                </Button>
              </div>
            </div>
            {err && <p role="alert" className="text-sm text-destructive">{err}</p>}
            <Button type="submit" className="w-full" disabled={busy}>{busy ? "Entrando…" : "Entrar"}</Button>
            <Button type="button" variant="link" className="w-full" onClick={() => { setRecoveryEmail(email); setRecoveryOpen(true); }}>
              Esqueci minha senha
            </Button>
          </form>
        </section>
      </div>

      <Dialog open={recoveryOpen} onOpenChange={setRecoveryOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Recuperar senha</DialogTitle>
            <DialogDescription>Informe o e-mail cadastrado. Enviaremos um link para criar uma nova senha.</DialogDescription>
          </DialogHeader>
          <form onSubmit={requestRecovery} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="recovery-email">E-mail</Label>
              <Input id="recovery-email" type="email" required maxLength={254} autoComplete="email" value={recoveryEmail} onChange={(e) => setRecoveryEmail(e.target.value)} placeholder="nome@empresa.com.br" />
            </div>
            {recoveryError && <p role="alert" className="text-sm text-destructive">{recoveryError}</p>}
            {recoveryInfo && <p role="status" className="text-sm text-success">{recoveryInfo}</p>}
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setRecoveryOpen(false)}>Cancelar</Button>
              <Button type="submit" disabled={recoveryBusy || Boolean(recoveryInfo)}>{recoveryBusy ? "Validando…" : "Enviar link"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </main>
  );
}
