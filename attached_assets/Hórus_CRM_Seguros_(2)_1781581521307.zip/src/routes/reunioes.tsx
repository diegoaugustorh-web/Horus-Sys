import { createFileRoute } from "@tanstack/react-router";
import { CalendarPlus, ExternalLink, MessageCircle, Video } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

import { Button, Card, Input, Label, Modal, PageHeader, Select, Textarea } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { type Cliente, useStore } from "@/lib/store";

type Reuniao = {
  id: string;
  clienteId?: string;
  titulo: string;
  dataHora: string;
  tipo: string;
  modalidade: string;
  linkReuniao?: string;
  enviarConvite: boolean;
  notificarCelular: boolean;
  observacoes?: string;
};

type FormState = {
  titulo: string;
  dataHora: string;
  clienteId: string;
  tipo: string;
  modalidade: string;
  linkReuniao: string;
  enviarConvite: boolean;
  notificarCelular: boolean;
  observacoes: string;
};

const initialForm = (): FormState => {
  const date = new Date(Date.now() + 60 * 60 * 1000);
  date.setMinutes(Math.ceil(date.getMinutes() / 15) * 15, 0, 0);
  return {
    titulo: "",
    dataHora: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}T${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`,
    clienteId: "",
    tipo: "Reunião",
    modalidade: "Microsoft Teams",
    linkReuniao: "",
    enviarConvite: true,
    notificarCelular: false,
    observacoes: "",
  };
};

export const Route = createFileRoute("/reunioes")({
  head: () => ({
    meta: [
      { title: "Reuniões — Hórus CRM" },
      { name: "description", content: "Agenda de reuniões e convites com clientes." },
    ],
  }),
  component: ReunioesPage,
});

function mapReuniao(row: Record<string, unknown>): Reuniao {
  return {
    id: String(row.id),
    clienteId: row.cliente_id ? String(row.cliente_id) : undefined,
    titulo: String(row.titulo),
    dataHora: String(row.data_hora),
    tipo: String(row.tipo),
    modalidade: String(row.modalidade),
    linkReuniao: row.link_reuniao ? String(row.link_reuniao) : undefined,
    enviarConvite: Boolean(row.enviar_convite),
    notificarCelular: Boolean(row.notificar_celular),
    observacoes: row.observacoes ? String(row.observacoes) : undefined,
  };
}

function ReunioesPage() {
  const { clientes, userId } = useStore();
  const [reunioes, setReunioes] = useState<Reuniao[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("reunioes").select("*").order("data_hora", { ascending: true });
    setReunioes((data ?? []).map((row) => mapReuniao(row as Record<string, unknown>)));
    setLoading(false);
  };

  useEffect(() => { void load(); }, []);

  const clienteById = useMemo(() => new Map(clientes.map((c) => [c.id, c])), [clientes]);
  const proximas = reunioes.filter((r) => new Date(r.dataHora).getTime() >= Date.now());

  return (
    <div className="p-6 lg:p-8">
      <PageHeader
        title="Reuniões"
        subtitle={`${proximas.length} compromisso${proximas.length === 1 ? "" : "s"} agendado${proximas.length === 1 ? "" : "s"}`}
        action={<Button onClick={() => setOpen(true)}>+ Nova reunião</Button>}
      />

      <Card>
        <div className="divide-y divide-border">
          {loading && <p className="p-8 text-sm text-center text-muted-foreground">Carregando agenda…</p>}
          {!loading && reunioes.length === 0 && (
            <div className="p-10 text-center">
              <CalendarPlus className="mx-auto mb-3 h-8 w-8 text-muted-foreground" />
              <p className="font-medium">Nenhuma reunião agendada</p>
              <p className="mt-1 text-sm text-muted-foreground">Crie um compromisso e envie o convite ao cliente.</p>
            </div>
          )}
          {reunioes.map((reuniao) => {
            const cliente = reuniao.clienteId ? clienteById.get(reuniao.clienteId) : undefined;
            return (
              <div key={reuniao.id} className="flex flex-col gap-4 p-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex min-w-0 gap-3">
                  <div className="rounded-md bg-primary/10 px-3 py-2 text-center text-primary">
                    <div className="text-[10px] font-semibold uppercase">{new Date(reuniao.dataHora).toLocaleDateString("pt-BR", { month: "short" })}</div>
                    <div className="text-lg font-bold leading-none">{new Date(reuniao.dataHora).getDate()}</div>
                  </div>
                  <div className="min-w-0">
                    <h2 className="truncate font-medium">{reuniao.titulo}</h2>
                    <p className="mt-0.5 text-sm text-muted-foreground">
                      {new Date(reuniao.dataHora).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" })}
                      {cliente ? ` · ${cliente.nome}` : ""}
                    </p>
                    <p className="mt-1 text-xs text-muted-foreground">{reuniao.tipo} · {reuniao.modalidade}</p>
                  </div>
                </div>
                <div className="flex shrink-0 flex-wrap gap-2">
                  {reuniao.linkReuniao && (
                    <Button variant="secondary" size="sm" onClick={() => window.open(reuniao.linkReuniao, "_blank", "noopener,noreferrer")}>
                      <Video /> Entrar
                    </Button>
                  )}
                  <Button variant="secondary" size="sm" onClick={() => downloadCalendar(reuniao, cliente)}>
                    <CalendarPlus /> Agenda
                  </Button>
                  {cliente?.telefone && (
                    <Button variant="secondary" size="sm" onClick={() => notifyWhatsApp(reuniao, cliente)}>
                      <MessageCircle /> Avisar
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      <NovaReuniaoModal
        open={open}
        clientes={clientes}
        userId={userId}
        onClose={() => setOpen(false)}
        onCreated={async () => { setOpen(false); await load(); }}
      />
    </div>
  );
}

function NovaReuniaoModal({ open, clientes, userId, onClose, onCreated }: {
  open: boolean;
  clientes: Cliente[];
  userId: string | null;
  onClose: () => void;
  onCreated: () => Promise<void>;
}) {
  const [form, setForm] = useState<FormState>(initialForm);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const cliente = clientes.find((c) => c.id === form.clienteId);
  const online = form.modalidade === "Microsoft Teams" || form.modalidade === "Google Meet";

  useEffect(() => {
    if (open) { setForm(initialForm()); setError(""); }
  }, [open]);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!userId) return;
    if (online && !form.linkReuniao.trim()) {
      setError("Informe o link da reunião online.");
      return;
    }
    setSaving(true);
    setError("");
    const { data, error: insertError } = await supabase.from("reunioes").insert({
      owner_id: userId,
      cliente_id: form.clienteId || null,
      titulo: form.titulo.trim(),
      data_hora: new Date(form.dataHora).toISOString(),
      tipo: form.tipo,
      modalidade: form.modalidade,
      link_reuniao: form.linkReuniao.trim() || null,
      enviar_convite: form.enviarConvite,
      notificar_celular: form.notificarCelular,
      observacoes: form.observacoes.trim() || null,
    }).select("*").single();

    if (insertError || !data) {
      setError(insertError?.message ?? "Não foi possível criar a reunião.");
      setSaving(false);
      return;
    }

    const reuniao = mapReuniao(data as Record<string, unknown>);
    if (form.enviarConvite) downloadCalendar(reuniao, cliente);
    if (form.notificarCelular && cliente?.telefone) notifyWhatsApp(reuniao, cliente);
    await onCreated();
    setSaving(false);
  };

  return (
    <Modal open={open} onClose={onClose} title="Nova reunião">
      <form onSubmit={submit} className="space-y-4">
        <div><Label>Título *</Label><Input required maxLength={200} autoFocus value={form.titulo} onChange={(e) => setForm({ ...form, titulo: e.target.value })} /></div>
        <div><Label>Data e hora *</Label><Input required type="datetime-local" value={form.dataHora} onChange={(e) => setForm({ ...form, dataHora: e.target.value })} /></div>
        <div>
          <Label>Contato</Label>
          <Select value={form.clienteId} onChange={(e) => setForm({ ...form, clienteId: e.target.value })}>
            <option value="">Selecionar contato</option>
            {clientes.map((c) => <option key={c.id} value={c.id}>{c.nome}</option>)}
          </Select>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div><Label>Tipo</Label><Select value={form.tipo} onChange={(e) => setForm({ ...form, tipo: e.target.value })}>{["Reunião", "Ligação", "Apresentação", "Follow-up"].map((v) => <option key={v}>{v}</option>)}</Select></div>
          <div><Label>Modalidade</Label><Select value={form.modalidade} onChange={(e) => setForm({ ...form, modalidade: e.target.value, linkReuniao: e.target.value === "Presencial" || e.target.value === "Telefone" ? "" : form.linkReuniao })}>{["Microsoft Teams", "Google Meet", "Presencial", "Telefone"].map((v) => <option key={v}>{v}</option>)}</Select></div>
        </div>
        {online && (
          <div><Label>Link de {form.modalidade} *</Label><div className="relative"><Input required type="url" placeholder="https://…" className="pr-9" value={form.linkReuniao} onChange={(e) => setForm({ ...form, linkReuniao: e.target.value })} /><ExternalLink className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" /></div></div>
        )}
        <div><Label>Observações</Label><Textarea rows={3} maxLength={5000} value={form.observacoes} onChange={(e) => setForm({ ...form, observacoes: e.target.value })} /></div>
        <div className="rounded-md border border-border bg-muted/30 p-3 space-y-3">
          <label className="flex cursor-pointer items-start gap-3 text-sm"><input type="checkbox" className="mt-0.5 h-4 w-4 accent-primary" checked={form.enviarConvite} onChange={(e) => setForm({ ...form, enviarConvite: e.target.checked })} /><span><strong className="block font-medium">Enviar convite para agenda</strong><span className="text-xs text-muted-foreground">Baixa um convite compatível com Google Agenda, Outlook e Apple Calendar.</span></span></label>
          <label className="flex cursor-pointer items-start gap-3 text-sm"><input type="checkbox" className="mt-0.5 h-4 w-4 accent-primary" checked={form.notificarCelular} disabled={!cliente?.telefone} onChange={(e) => setForm({ ...form, notificarCelular: e.target.checked })} /><span><strong className="block font-medium">Notificar celular por WhatsApp</strong><span className="text-xs text-muted-foreground">{cliente?.telefone ? `Envia o aviso para ${cliente.telefone}.` : "Selecione um contato com telefone cadastrado."}</span></span></label>
        </div>
        {error && <p className="text-sm text-destructive">{error}</p>}
        <div className="flex justify-end gap-2 pt-2"><Button type="button" variant="secondary" onClick={onClose}>Cancelar</Button><Button type="submit" disabled={saving}>{saving ? "Criando…" : "Criar reunião"}</Button></div>
      </form>
    </Modal>
  );
}

function calendarContent(reuniao: Reuniao, cliente?: Cliente) {
  const start = new Date(reuniao.dataHora);
  const end = new Date(start.getTime() + 60 * 60 * 1000);
  const stamp = (date: Date) => date.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
  const clean = (text: string) => text.replace(/\\/g, "\\\\").replace(/\n/g, "\\n").replace(/,/g, "\\,").replace(/;/g, "\\;");
  const description = [reuniao.observacoes, reuniao.linkReuniao].filter(Boolean).join("\n");
  return ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Horus CRM//Reunioes//PT-BR", "CALSCALE:GREGORIAN", "METHOD:REQUEST", "BEGIN:VEVENT", `UID:${reuniao.id}@horus-crm`, `DTSTAMP:${stamp(new Date())}`, `DTSTART:${stamp(start)}`, `DTEND:${stamp(end)}`, `SUMMARY:${clean(reuniao.titulo)}`, `DESCRIPTION:${clean(description)}`, `LOCATION:${clean(reuniao.modalidade)}`, cliente?.email ? `ATTENDEE;CN=${clean(cliente.nome)};RSVP=TRUE:mailto:${cliente.email}` : "", "END:VEVENT", "END:VCALENDAR"].filter(Boolean).join("\r\n");
}

function downloadCalendar(reuniao: Reuniao, cliente?: Cliente) {
  const blob = new Blob([calendarContent(reuniao, cliente)], { type: "text/calendar;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `${reuniao.titulo.replace(/[^a-z0-9]+/gi, "-").toLowerCase() || "reuniao"}.ics`;
  anchor.click();
  URL.revokeObjectURL(url);
}

function notifyWhatsApp(reuniao: Reuniao, cliente: Cliente) {
  const phone = cliente.telefone.replace(/\D/g, "");
  const normalized = phone.startsWith("55") ? phone : `55${phone}`;
  const when = new Date(reuniao.dataHora).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
  const message = `Olá, ${cliente.nome}! Você tem ${reuniao.tipo.toLowerCase()} agendada para ${when}. Modalidade: ${reuniao.modalidade}.${reuniao.linkReuniao ? ` Link: ${reuniao.linkReuniao}` : ""}`;
  window.open(`https://wa.me/${normalized}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
}