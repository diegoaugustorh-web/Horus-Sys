import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useStore, actions, fmtBRL, fmtDate, usePerms, type StatusComissao } from "@/lib/store";
import { Button, Card, PageHeader, Select, StatusBadge } from "@/components/AppShell";

export const Route = createFileRoute("/comissoes")({
  head: () => ({
    meta: [
      { title: "Comissões — Hórus CRM" },
      { name: "description", content: "Controle de comissões por apólice e parcelas a receber." },
    ],
  }),
  component: ComissoesPage,
});

const STATUS: StatusComissao[] = ["A Receber", "Recebida", "Atrasada"];

function ComissoesPage() {
  const { comissoes, apolices, clientes } = useStore();
  const { canManageSeguros } = usePerms();
  const [filtro, setFiltro] = useState<"" | StatusComissao>("");

  const cliMap = Object.fromEntries(clientes.map((c) => [c.id, c.nome]));
  const apMap = Object.fromEntries(apolices.map((a) => [a.id, a]));

  const filtradas = [...comissoes].sort((a, b) => a.vencimento.localeCompare(b.vencimento)).filter((c) => !filtro || c.status === filtro);

  const stats = {
    aReceber: comissoes.filter((c) => c.status === "A Receber").reduce((s, c) => s + c.valor, 0),
    recebido: comissoes.filter((c) => c.status === "Recebida").reduce((s, c) => s + c.valor, 0),
    atrasado: comissoes.filter((c) => c.status === "Atrasada").reduce((s, c) => s + c.valor, 0),
  };

  return (
    <div className="p-6 lg:p-8">
      <PageHeader title="Comissões" subtitle="Recebíveis por apólice e parcela" />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card className="p-5">
          <div className="text-xs text-muted-foreground uppercase font-medium tracking-wide">A receber</div>
          <div className="text-2xl font-semibold text-info mt-2">{fmtBRL(stats.aReceber)}</div>
        </Card>
        <Card className="p-5">
          <div className="text-xs text-muted-foreground uppercase font-medium tracking-wide">Recebido</div>
          <div className="text-2xl font-semibold text-success mt-2">{fmtBRL(stats.recebido)}</div>
        </Card>
        <Card className="p-5">
          <div className="text-xs text-muted-foreground uppercase font-medium tracking-wide">Em atraso</div>
          <div className="text-2xl font-semibold text-destructive mt-2">{fmtBRL(stats.atrasado)}</div>
        </Card>
      </div>

      <Card className="p-4 mb-4 flex gap-3">
        <div className="w-48">
          <Select value={filtro} onChange={(e) => setFiltro(e.target.value as "" | StatusComissao)}>
            <option value="">Todos os status</option>
            {STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
          </Select>
        </div>
      </Card>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-muted-foreground border-b border-border bg-muted/40">
                <th className="font-medium px-4 py-3">Apólice</th>
                <th className="font-medium px-4 py-3">Cliente</th>
                <th className="font-medium px-4 py-3">Seguradora</th>
                <th className="font-medium px-4 py-3">Parcela</th>
                <th className="font-medium px-4 py-3 text-right">Valor</th>
                <th className="font-medium px-4 py-3">Vencimento</th>
                <th className="font-medium px-4 py-3">Status</th>
                <th className="font-medium px-4 py-3 text-right">Ação</th>
              </tr>
            </thead>
            <tbody>
              {filtradas.map((c) => {
                const ap = apMap[c.apoliceId];
                return (
                  <tr key={c.id} className="border-b border-border/50 last:border-0 hover:bg-muted/30">
                    <td className="px-4 py-3 font-mono text-xs">{ap?.numero || "—"}</td>
                    <td className="px-4 py-3 font-medium">{ap ? cliMap[ap.clienteId] : "—"}</td>
                    <td className="px-4 py-3 text-muted-foreground">{ap?.seguradora || "—"}</td>
                    <td className="px-4 py-3 text-xs">{c.parcela}/{c.totalParcelas}</td>
                    <td className="px-4 py-3 text-right font-medium">{fmtBRL(c.valor)}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{fmtDate(c.vencimento)}</td>
                    <td className="px-4 py-3"><StatusBadge status={c.status} /></td>
                    <td className="px-4 py-3 text-right">
                      {canManageSeguros ? (
                        c.status !== "Recebida" ? (
                          <Button size="sm" onClick={() => actions.updateComissaoStatus(c.id, "Recebida")}>Marcar recebida</Button>
                        ) : (
                          <Button size="sm" variant="ghost" onClick={() => actions.updateComissaoStatus(c.id, "A Receber")}>Reabrir</Button>
                        )
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </td>
                  </tr>
                );
              })}
              {filtradas.length === 0 && (
                <tr><td colSpan={8} className="px-4 py-10 text-center text-muted-foreground text-sm">Nenhuma comissão encontrada.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
