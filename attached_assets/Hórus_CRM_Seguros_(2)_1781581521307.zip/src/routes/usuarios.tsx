import { createFileRoute, redirect, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import {
  AppShell,
  PageHeader,
  Card,
  Button,
  Input,
  Label,
  Select,
  Modal,
} from "@/components/AppShell";
import {
  useStore,
  listUsuarios,
  setUsuarioRole,
  ROLE_LABEL,
  type UserSummary,
  type Role,
} from "@/lib/store";
import {
  adminCreateUser,
  adminSendPasswordReset,
  adminDeleteUser,
  adminCheck,
} from "@/lib/users.functions";

export const Route = createFileRoute("/usuarios")({
  ssr: false,
  beforeLoad: async () => {
    try {
      await adminCheck();
    } catch {
      throw redirect({ to: "/" });
    }
  },
  component: UsuariosPage,
  head: () => ({
    meta: [
      { title: "Usuários — Hórus CRM" },
      { name: "description", content: "Gerencie usuários e perfis de acesso." },
    ],
  }),
});

function UsuariosPage() {
  const { ready, role } = useStore();
  const navigate = useNavigate();
  const [users, setUsers] = useState<UserSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [openCreate, setOpenCreate] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  useEffect(() => {
    if (ready && role && role !== "admin") {
      navigate({ to: "/" });
    }
  }, [ready, role, navigate]);

  const refresh = async () => {
    setLoading(true);
    try {
      setUsers(await listUsuarios());
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (role === "admin") refresh();
  }, [role]);

  const sendReset = useServerFn(adminSendPasswordReset);
  const deleteUser = useServerFn(adminDeleteUser);

  const onChangeRole = async (id: string, newRole: Role) => {
    setErr(null);
    try {
      await setUsuarioRole(id, newRole);
      await refresh();
    } catch (e: any) {
      setErr(e?.message ?? "Falha ao alterar perfil");
    }
  };

  const onReset = async (email: string) => {
    setErr(null);
    setInfo(null);
    try {
      await sendReset({ data: { email } });
      setInfo(`Link de redefinição gerado para ${email}.`);
    } catch (e: any) {
      setErr(e?.message ?? "Falha ao enviar redefinição");
    }
  };

  const onDelete = async (u: UserSummary) => {
    if (!confirm(`Remover ${u.email}? Esta ação não pode ser desfeita.`)) return;
    setErr(null);
    try {
      await deleteUser({ data: { userId: u.id } });
      await refresh();
    } catch (e: any) {
      setErr(e?.message ?? "Falha ao remover");
    }
  };

  if (!ready || role !== "admin") {
    return (
      <AppShell>
        <div className="p-6 text-sm text-muted-foreground">Carregando…</div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="p-4 lg:p-6">
        <PageHeader
          title="Usuários"
          subtitle="Cadastre novos acessos e defina o perfil de cada usuário."
          action={<Button onClick={() => setOpenCreate(true)}>Novo usuário</Button>}
        />

        {err && (
          <div className="mb-4 text-xs text-destructive bg-destructive/5 border border-destructive/20 rounded-md px-3 py-2">
            {err}
          </div>
        )}
        {info && (
          <div className="mb-4 text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-md px-3 py-2">
            {info}
          </div>
        )}

        <Card>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/40 text-xs uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="text-left px-4 py-2.5 font-medium">Nome</th>
                  <th className="text-left px-4 py-2.5 font-medium">Email</th>
                  <th className="text-left px-4 py-2.5 font-medium">Perfil</th>
                  <th className="text-left px-4 py-2.5 font-medium">Criado</th>
                  <th className="px-4 py-2.5" />
                </tr>
              </thead>
              <tbody>
                {loading && (
                  <tr><td colSpan={5} className="px-4 py-6 text-center text-muted-foreground">Carregando…</td></tr>
                )}
                {!loading && users.length === 0 && (
                  <tr><td colSpan={5} className="px-4 py-6 text-center text-muted-foreground">Nenhum usuário.</td></tr>
                )}
                {users.map((u) => (
                  <tr key={u.id} className="border-t border-border">
                    <td className="px-4 py-2.5">{u.nome || "—"}</td>
                    <td className="px-4 py-2.5 text-muted-foreground">{u.email}</td>
                    <td className="px-4 py-2.5">
                      <Select
                        value={u.role ?? "corretor"}
                        onChange={(e) => onChangeRole(u.id, e.target.value as Role)}
                        className="max-w-[180px]"
                      >
                        <option value="admin">{ROLE_LABEL.admin}</option>
                        <option value="corretor">{ROLE_LABEL.corretor}</option>
                        <option value="atendente">{ROLE_LABEL.atendente}</option>
                      </Select>
                    </td>
                    <td className="px-4 py-2.5 text-muted-foreground">{u.criadoEm}</td>
                    <td className="px-4 py-2.5 text-right whitespace-nowrap">
                      <Button size="sm" variant="ghost" onClick={() => onReset(u.email)}>
                        Redefinir senha
                      </Button>
                      <Button size="sm" variant="danger" onClick={() => onDelete(u)}>
                        Remover
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>

      <CreateUserModal
        open={openCreate}
        onClose={() => setOpenCreate(false)}
        onCreated={async (msg) => {
          setOpenCreate(false);
          setInfo(msg);
          await refresh();
        }}
        onError={(m) => setErr(m)}
      />
    </AppShell>
  );
}

function CreateUserModal({
  open,
  onClose,
  onCreated,
  onError,
}: {
  open: boolean;
  onClose: () => void;
  onCreated: (info: string) => void;
  onError: (msg: string) => void;
}) {
  const create = useServerFn(adminCreateUser);
  const [email, setEmail] = useState("");
  const [nome, setNome] = useState("");
  const [role, setRole] = useState<Role>("corretor");
  const [mode, setMode] = useState<"invite" | "password">("invite");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) {
      setEmail(""); setNome(""); setRole("corretor"); setMode("invite"); setPassword(""); setBusy(false);
    }
  }, [open]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      await create({ data: { email, nome, role, mode, password: mode === "password" ? password : undefined } });
      onCreated(
        mode === "invite"
          ? `Convite enviado para ${email}.`
          : `Usuário ${email} criado com senha definida.`,
      );
    } catch (err: any) {
      onError(err?.message ?? "Falha ao criar usuário");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title="Novo usuário">
      <form onSubmit={submit} className="space-y-3">
        <div>
          <Label>Nome</Label>
          <Input value={nome} onChange={(e) => setNome(e.target.value)} required placeholder="Nome completo" />
        </div>
        <div>
          <Label>Email</Label>
          <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <div>
          <Label>Perfil</Label>
          <Select value={role} onChange={(e) => setRole(e.target.value as Role)}>
            <option value="admin">{ROLE_LABEL.admin}</option>
            <option value="corretor">{ROLE_LABEL.corretor}</option>
            <option value="atendente">{ROLE_LABEL.atendente}</option>
          </Select>
        </div>
        <div>
          <Label>Acesso</Label>
          <div className="flex gap-2 p-1 bg-muted rounded-md">
            <button type="button" onClick={() => setMode("invite")}
              className={`flex-1 py-1.5 text-xs font-medium rounded ${mode === "invite" ? "bg-card shadow-sm" : "text-muted-foreground"}`}>
              Enviar convite por e-mail
            </button>
            <button type="button" onClick={() => setMode("password")}
              className={`flex-1 py-1.5 text-xs font-medium rounded ${mode === "password" ? "bg-card shadow-sm" : "text-muted-foreground"}`}>
              Definir senha
            </button>
          </div>
        </div>
        {mode === "password" && (
          <div>
            <Label>Senha inicial</Label>
            <Input
              type="text"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              minLength={6}
              required
              placeholder="Mínimo 6 caracteres"
              autoComplete="new-password"
            />
            <p className="text-[11px] text-muted-foreground mt-1">
              O usuário poderá alterar a senha após o primeiro acesso.
            </p>
          </div>
        )}
        {mode === "invite" && (
          <p className="text-[11px] text-muted-foreground">
            Um e-mail com link de definição de senha será enviado ao usuário.
          </p>
        )}
        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="secondary" onClick={onClose}>Cancelar</Button>
          <Button type="submit" disabled={busy}>{busy ? "Criando…" : "Criar usuário"}</Button>
        </div>
      </form>
    </Modal>
  );
}
