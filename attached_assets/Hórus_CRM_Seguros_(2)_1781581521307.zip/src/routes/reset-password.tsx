import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Eye, EyeOff, KeyRound } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/reset-password")({
  ssr: false,
  component: ResetPasswordPage,
  head: () => ({
    meta: [
      { title: "Redefinir senha — Hórus CRM" },
      { name: "description", content: "Defina uma nova senha para acessar o Hórus CRM." },
    ],
  }),
});

function ResetPasswordPage() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [show, setShow] = useState(false);
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setReady(Boolean(data.session)));
  }, []);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError(null);
    if (password.length < 8) return setError("A senha deve ter pelo menos 8 caracteres.");
    if (password !== confirm) return setError("As senhas não coincidem.");
    setBusy(true);
    const { error: updateError } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (updateError) return setError("O link expirou ou não é válido. Solicite um novo link.");
    await supabase.auth.signOut();
    navigate({ to: "/auth", search: { redirect: "/" }, replace: true });
  };

  return (
    <main className="min-h-screen bg-muted/30 px-4 py-10 flex items-center justify-center">
      <section className="w-full max-w-md rounded-xl border border-border bg-card p-6 shadow-elevated">
        <div className="mx-auto mb-4 flex size-11 items-center justify-center rounded-full bg-primary-soft text-primary">
          <KeyRound className="size-5" />
        </div>
        <h1 className="text-center text-xl font-semibold">Criar nova senha</h1>
        <p className="mt-2 text-center text-sm text-muted-foreground">
          Digite e confirme sua nova senha de acesso.
        </p>

        {!ready ? (
          <div className="mt-6 rounded-md bg-muted p-3 text-center text-sm text-muted-foreground">
            Link inválido ou expirado. Solicite uma nova recuperação na tela de login.
          </div>
        ) : (
          <form onSubmit={submit} className="mt-6 space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="new-password">Nova senha</Label>
              <div className="relative">
                <Input id="new-password" type={show ? "text" : "password"} required minLength={8} maxLength={128} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} className="pr-10" />
                <Button type="button" variant="ghost" size="icon" aria-label={show ? "Ocultar senha" : "Mostrar senha"} onClick={() => setShow((value) => !value)} className="absolute right-0 top-0 shadow-none">
                  {show ? <EyeOff /> : <Eye />}
                </Button>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="confirm-password">Confirmar nova senha</Label>
              <Input id="confirm-password" type={show ? "text" : "password"} required minLength={8} maxLength={128} autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
            </div>
            {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
            <Button type="submit" className="w-full" disabled={busy}>{busy ? "Salvando…" : "Salvar nova senha"}</Button>
          </form>
        )}
      </section>
    </main>
  );
}