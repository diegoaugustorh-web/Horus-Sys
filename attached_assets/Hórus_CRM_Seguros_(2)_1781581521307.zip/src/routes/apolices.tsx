import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useStore, actions, fmtBRL, fmtDate, usePerms, type RamoSeguro, type StatusApolice } from "@/lib/store";
import { Button, Card, Input, Label, Modal, PageHeader, Select, StatusBadge } from "@/components/AppShell";
import { ImportModal } from "@/components/ImportModal";

export const Route = createFileRoute("/apolices")({
  head: () => ({
    meta: [
      { title: "Apólices — Hórus CRM" },
      { name: "description", content: "Carteira de apólices: vigências, renovações e prêmios." },
    ],
  }),
  component: ApolicesPage,
});

const RAMOS: RamoSeguro[] = ["Auto", "Vida", "Residencial", "Empresarial", "Saúde", "Viagem"];
const STATUS: StatusApolice[] = ["Vigente", "A Renovar", "Vencida", "Cancelada"];

function ApolicesPage() {
  const { apolices, clientes } = useStore();
  const { canManageSeguros } = usePerms();
  const [open, setOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [q, setQ] = useState("");
  const [ramo, setRamo] = useState<"" | RamoSeguro>("");
  const [status, setStatus] = useState<"" | StatusApolice>("");

  const cliMap = Object.fromEntries(clientes.map((c) => [c.id, c.nome]));

  const filtradas = apolices.filter((a) => {
    const matchQ = !q || a.numero.toLowerCase().includes(q.toLowerCase()) || (cliMap[a.clienteId] || "").toLowerCase().includes(q.toLowerCase()) || a.seguradora.toLowerCase().includes(q.toLowerCase());
    return matchQ && (!ramo || a.ramo === ramo) && (!status || a.status === status);
  });

  const totalPremio = filtradas.reduce((s, a) => s + a.premio, 0);

  return (
    <div className="p-6 lg:p-8">
      <PageHeader
        title="Apólices"
        subtitle={`${filtradas.length} apólices · Prêmio total ${fmtBRL(totalPremio)}`}
        action={
          canManageSeguros ? (
            <div className="flex gap-2">
              <Button variant="secondary" onClick={() => setImportOpen(true)}>↑ Importar</Button>
              <Button onClick={() => setOpen(true)}>+ Nova apólice</Button>
            </div>
          ) : null
        }
      />

      <Card className="p-4 mb-4 grid md:grid-cols-4 gap-3">
        <Input placeholder="Buscar nº, cliente, seguradora…" value={q} onChange={(e) => setQ(e.target.value)} />
        <Select value={ramo} onChange={(e) => setRamo(e.target.value as "" | RamoSeguro)}>
          <option value="">Todos os ramos</option>
          {RAMOS.map((r) => <option key={r} value={r}>{r}</option>)}
        </Select>
        <Select value={status} onChange={(e) => setStatus(e.target.value as "" | StatusApolice)}>
          <option value="">Todos os status</option>
          {STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
        </Select>
      </Card>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-muted-foreground border-b border-border bg-muted/40">
                <th className="font-medium px-4 py-3">Nº Apólice</th>
                <th className="font-medium px-4 py-3">Cliente</th>
                <th className="font-medium px-4 py-3">Seguradora</th>
                <th className="font-medium px-4 py-3">Ramo</th>
                <th className="font-medium px-4 py-3 text-right">Prêmio</th>
                <th className="font-medium px-4 py-3">Vigência</th>
                <th className="font-medium px-4 py-3">Status</th>
                <th className="font-medium px-4 py-3 text-right">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filtradas.map((a) => (
                <tr key={a.id} className="border-b border-border/50 last:border-0 hover:bg-muted/30">
                  <td className="px-4 py-3 font-mono text-xs">{a.numero}</td>
                  <td className="px-4 py-3 font-medium">{cliMap[a.clienteId] || "—"}</td>
                  <td className="px-4 py-3">{a.seguradora}</td>
                  <td className="px-4 py-3 text-muted-foreground">{a.ramo}</td>
                  <td className="px-4 py-3 text-right">{fmtBRL(a.premio)}</td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{fmtDate(a.inicio)} → {fmtDate(a.fim)}</td>
                  <td className="px-4 py-3">
                    {canManageSeguros ? (
                      <Select value={a.status} onChange={(e) => actions.updateApoliceStatus(a.id, e.target.value as StatusApolice)} className="h-7 text-xs py-0">
                        {STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
                      </Select>
                    ) : (
                      <StatusBadge status={a.status} />
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    {canManageSeguros && (
                      <Button variant="danger" size="sm" onClick={() => confirm(`Excluir apólice ${a.numero}?`) && actions.removeApolice(a.id)}>Excluir</Button>
                    )}
                  </td>
                </tr>
              ))}
              {filtradas.length === 0 && (
                <tr><td colSpan={8} className="px-4 py-10 text-center text-muted-foreground text-sm">Nenhuma apólice encontrada.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      <NovaApoliceModal open={open} onClose={() => setOpen(false)} />
      <ImportModal open={importOpen} onClose={() => setImportOpen(false)} kind="apolices" />
    </div>
  );
}

function NovaApoliceModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { clientes } = useStore();
  const ano = new Date().getFullYear();
  const [form, setForm] = useState({
    numero: `AP-${ano}-${String(Math.floor(Math.random() * 99999)).padStart(5, "0")}`,
    clienteId: "",
    seguradora: "",
    ramo: "Auto" as RamoSeguro,
    premio: 0,
    inicio: new Date().toISOString().slice(0, 10),
    fim: new Date(Date.now() + 365 * 86400000).toISOString().slice(0, 10),
    status: "Vigente" as StatusApolice,
    comissaoPct: 15,
  });
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.clienteId || !form.seguradora) return;
    actions.addApolice(form);
    onClose();
  };
  return (
    <Modal open={open} onClose={onClose} title="Nova apólice">
      <form onSubmit={submit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Nº Apólice</Label><Input value={form.numero} onChange={(e) => setForm({ ...form, numero: e.target.value })} /></div>
          <div>
            <Label>Cliente</Label>
            <Select value={form.clienteId} onChange={(e) => setForm({ ...form, clienteId: e.target.value })} required>
              <option value="">Selecione…</option>
              {clientes.map((c) => <option key={c.id} value={c.id}>{c.nome}</option>)}
            </Select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Seguradora</Label><Input value={form.seguradora} onChange={(e) => setForm({ ...form, seguradora: e.target.value })} required /></div>
          <div>
            <Label>Ramo</Label>
            <Select value={form.ramo} onChange={(e) => setForm({ ...form, ramo: e.target.value as RamoSeguro })}>
              {RAMOS.map((r) => <option key={r} value={r}>{r}</option>)}
            </Select>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div><Label>Prêmio anual (R$)</Label><Input type="number" step="0.01" value={form.premio} onChange={(e) => setForm({ ...form, premio: Number(e.target.value) })} /></div>
          <div><Label>Comissão (%)</Label><Input type="number" step="0.5" value={form.comissaoPct} onChange={(e) => setForm({ ...form, comissaoPct: Number(e.target.value) })} /></div>
          <div>
            <Label>Status</Label>
            <Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as StatusApolice })}>
              {STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
            </Select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Início da vigência</Label><Input type="date" value={form.inicio} onChange={(e) => setForm({ ...form, inicio: e.target.value })} /></div>
          <div><Label>Fim da vigência</Label><Input type="date" value={form.fim} onChange={(e) => setForm({ ...form, fim: e.target.value })} /></div>
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="secondary" onClick={onClose}>Cancelar</Button>
          <Button type="submit">Salvar apólice</Button>
        </div>
      </form>
    </Modal>
  );
}

// Suppress unused-import warning for shared component
void StatusBadge;
