import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { usePerms, type Produto } from "@/lib/store";
import { Button, Card, Input, Label, Modal, PageHeader, Select } from "@/components/AppShell";

export const Route = createFileRoute("/produtos")({
  head: () => ({
    meta: [
      { title: "Produtos — Hórus CRM" },
      { name: "description", content: "Catálogo de produtos (seguros e consórcios)." },
    ],
  }),
  component: ProdutosPage,
});

type FormState = {
  nome: string;
  categoria: "seguro" | "consorcio";
  tipoPessoa: "PF" | "PJ" | "AMBOS";
  ativo: boolean;
};

const EMPTY: FormState = { nome: "", categoria: "seguro", tipoPessoa: "AMBOS", ativo: true };

function ProdutosPage() {
  const { isAdmin } = usePerms();
  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [loading, setLoading] = useState(true);
  const [openCad, setOpenCad] = useState(false);
  const [editing, setEditing] = useState<Produto | null>(null);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase.from("produtos").select("*").order("nome");
    if (!error && data) {
      setProdutos(
        data.map((r: any) => ({
          id: r.id,
          categoria: r.categoria,
          tipoPessoa: r.tipo_pessoa,
          nome: r.nome,
          ativo: r.ativo,
        })),
      );
    }
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="p-6 lg:p-8">
      <PageHeader
        title="Produtos"
        subtitle={`${produtos.length} produtos cadastrados`}
        action={
          isAdmin ? <Button onClick={() => setOpenCad(true)}>+ Cadastro</Button> : null
        }
      />

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-muted-foreground border-b border-border bg-muted/40">
                <th className="font-medium px-4 py-3">Nome</th>
                <th className="font-medium px-4 py-3">Categoria</th>
                <th className="font-medium px-4 py-3">Tipo Pessoa</th>
                <th className="font-medium px-4 py-3">Status</th>
                <th className="font-medium px-4 py-3 text-right">Ações</th>
              </tr>
            </thead>
            <tbody>
              {produtos.map((p) => (
                <tr key={p.id} className="border-b border-border/50 last:border-0 hover:bg-muted/30">
                  <td className="px-4 py-3 font-medium">{p.nome}</td>
                  <td className="px-4 py-3 capitalize">{p.categoria}</td>
                  <td className="px-4 py-3">{p.tipoPessoa}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${p.ativo ? "bg-success/10 text-success border-success/20" : "bg-muted text-muted-foreground border-border"}`}>
                      {p.ativo ? "Ativo" : "Inativo"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    {isAdmin && (
                      <Button size="sm" variant="secondary" onClick={() => setEditing(p)}>
                        Edição
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
              {!loading && produtos.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-10 text-center text-muted-foreground text-sm">
                    Nenhum produto cadastrado.
                  </td>
                </tr>
              )}
              {loading && (
                <tr>
                  <td colSpan={5} className="px-4 py-10 text-center text-muted-foreground text-sm">
                    Carregando…
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      <ProdutoModal
        open={openCad}
        onClose={() => setOpenCad(false)}
        title="Cadastrar produto"
        initial={EMPTY}
        onSubmit={async (form) => {
          const { error } = await supabase.from("produtos").insert({
            nome: form.nome,
            categoria: form.categoria,
            tipo_pessoa: form.tipoPessoa,
            ativo: form.ativo,
          });
          if (error) {
            alert("Erro ao cadastrar: " + error.message);
            return;
          }
          setOpenCad(false);
          load();
        }}
      />

      <ProdutoModal
        open={!!editing}
        onClose={() => setEditing(null)}
        title="Editar produto"
        initial={
          editing
            ? { nome: editing.nome, categoria: editing.categoria, tipoPessoa: editing.tipoPessoa, ativo: editing.ativo }
            : EMPTY
        }
        onSubmit={async (form) => {
          if (!editing) return;
          const { error } = await supabase
            .from("produtos")
            .update({
              nome: form.nome,
              categoria: form.categoria,
              tipo_pessoa: form.tipoPessoa,
              ativo: form.ativo,
            })
            .eq("id", editing.id);
          if (error) {
            alert("Erro ao atualizar: " + error.message);
            return;
          }
          setEditing(null);
          load();
        }}
      />
    </div>
  );
}

function ProdutoModal({
  open,
  onClose,
  title,
  initial,
  onSubmit,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  initial: FormState;
  onSubmit: (f: FormState) => void | Promise<void>;
}) {
  const [form, setForm] = useState<FormState>(initial);

  useEffect(() => {
    if (open) setForm(initial);
  }, [open, initial]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nome.trim()) return;
    onSubmit(form);
  };

  return (
    <Modal open={open} onClose={onClose} title={title}>
      <form onSubmit={submit} className="space-y-4">
        <div>
          <Label>Nome</Label>
          <Input value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} required />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Categoria</Label>
            <Select
              value={form.categoria}
              onChange={(e) => setForm({ ...form, categoria: e.target.value as "seguro" | "consorcio" })}
            >
              <option value="seguro">Seguro</option>
              <option value="consorcio">Consórcio</option>
            </Select>
          </div>
          <div>
            <Label>Tipo de Pessoa</Label>
            <Select
              value={form.tipoPessoa}
              onChange={(e) => setForm({ ...form, tipoPessoa: e.target.value as "PF" | "PJ" | "AMBOS" })}
            >
              <option value="AMBOS">Ambos</option>
              <option value="PF">Pessoa Física</option>
              <option value="PJ">Pessoa Jurídica</option>
            </Select>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <input
            id="ativo"
            type="checkbox"
            checked={form.ativo}
            onChange={(e) => setForm({ ...form, ativo: e.target.checked })}
            className="h-4 w-4"
          />
          <label htmlFor="ativo" className="text-sm">Produto ativo</label>
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="secondary" onClick={onClose}>Cancelar</Button>
          <Button type="submit">Salvar</Button>
        </div>
      </form>
    </Modal>
  );
}
