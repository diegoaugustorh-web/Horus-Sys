import { createFileRoute } from "@tanstack/react-router";
import React, { useEffect, useMemo, useRef, useState } from "react";

import {
  useStore, actions, fmtDate, usePerms, listProdutos,
  listAnexos, uploadAnexo, downloadAnexo, removeAnexo,
  type Produto, type Cliente, type Anexo, fmtBRL,
} from "@/lib/store";
import { Button, Card, Input, Label, Modal, PageHeader, Select } from "@/components/AppShell";
import { ImportModal } from "@/components/ImportModal";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";


export const Route = createFileRoute("/clientes")({
  head: () => ({
    meta: [
      { title: "Clientes — Hórus CRM" },
      { name: "description", content: "Cadastro completo de segurados PF e PJ." },
    ],
  }),
  component: ClientesPage,
});

function ClientesPage() {
  const { clientes, apolices } = useStore();
  const { canDeleteClientes } = usePerms();
  const [open, setOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [q, setQ] = useState("");
  const [tipo, setTipo] = useState<"" | "PF" | "PJ">("");
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Cliente | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [produtos, setProdutos] = useState<Produto[]>([]);

  useEffect(() => {
    listProdutos().then(setProdutos).catch(() => setProdutos([]));
  }, []);
  const produtoNome = (id?: string) => produtos.find((x) => x.id === id)?.nome;



  const filtrados = clientes.filter((c) => {
    const matchQ = !q || c.nome.toLowerCase().includes(q.toLowerCase()) || c.cpfCnpj.includes(q) || c.email.toLowerCase().includes(q.toLowerCase());
    const matchT = !tipo || c.tipo === tipo;
    return matchQ && matchT;
  });

  return (
    <div className="p-6 lg:p-8">
      <PageHeader
        title="Clientes"
        subtitle={`${clientes.length} segurados cadastrados`}
        action={
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => setImportOpen(true)}>↑ Importar</Button>
            <Button onClick={() => setOpen(true)}>+ Novo cliente</Button>
          </div>
        }
      />

      <Card className="p-4 mb-4 flex flex-wrap gap-3">
        <div className="flex-1 min-w-[220px]">
          <Input placeholder="Buscar por nome, CPF/CNPJ ou email…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="w-40">
          <Select value={tipo} onChange={(e) => setTipo(e.target.value as "" | "PF" | "PJ")}>
            <option value="">Todos os tipos</option>
            <option value="PF">Pessoa Física</option>
            <option value="PJ">Pessoa Jurídica</option>
          </Select>
        </div>
      </Card>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-muted-foreground border-b border-border bg-muted/40">
                <th className="font-medium px-4 py-3">Nome</th>
                <th className="font-medium px-4 py-3">Tipo</th>
                <th className="font-medium px-4 py-3">CPF/CNPJ</th>
                <th className="font-medium px-4 py-3">Contato</th>
                <th className="font-medium px-4 py-3">Cidade</th>
                <th className="font-medium px-4 py-3">Apólices</th>
                <th className="font-medium px-4 py-3">Desde</th>
                <th className="font-medium px-4 py-3 text-right">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filtrados.map((c) => {
                const qtd = apolices.filter((a) => a.clienteId === c.id).length;
                const isOpen = expandedId === c.id;
                return (
                  <React.Fragment key={c.id}>
                  <tr className="border-b border-border/50 hover:bg-muted/30">
                    <td className="px-4 py-3 font-medium">{c.nome}</td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs border border-border bg-muted/50">{c.tipo}</span>
                    </td>
                    <td className="px-4 py-3 font-mono text-xs">{c.cpfCnpj}</td>
                    <td className="px-4 py-3 text-xs">
                      <div>{c.email}</div>
                      <div className="text-muted-foreground">{c.telefone}</div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{c.cidade}</td>
                    <td className="px-4 py-3">{qtd}</td>
                    <td className="px-4 py-3 text-muted-foreground">{fmtDate(c.criadoEm)}</td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <Button variant="secondary" size="sm" onClick={() => { setExpandedId(isOpen ? null : c.id); if (isOpen) setEditingId(null); }}>
                        {isOpen ? "Ocultar" : "Ver detalhes"}
                      </Button>
                      <Button className="ml-2" variant="secondary" size="sm"
                        onClick={() => { setExpandedId(c.id); setEditingId(c.id); }}>
                        ✎ Editar
                      </Button>
                      {canDeleteClientes && (
                        <Button className="ml-2" variant="danger" size="sm" onClick={() => setDeleteTarget(c)}>Excluir</Button>
                      )}
                    </td>
                  </tr>
                  {isOpen && (
                    <tr className="border-b border-border/50 bg-muted/20">
                      <td colSpan={8} className="p-0">
                        <div className="sticky left-0 w-screen max-w-[100vw] lg:w-auto lg:max-w-none px-4 py-4">
                          <ClienteDetalhes
                            cliente={c}
                            produtoNome={produtoNome(c.produtoId)}
                            produtos={produtos}
                            editing={editingId === c.id}
                            onEditingChange={(v) => setEditingId(v ? c.id : null)}
                          />
                        </div>
                      </td>
                    </tr>
                  )}
                  </React.Fragment>
                );
              })}


              {filtrados.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-4 py-10 text-center text-muted-foreground text-sm">Nenhum cliente encontrado.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      <NovoClienteModal open={open} onClose={() => setOpen(false)} />
      <ImportModal open={importOpen} onClose={() => setImportOpen(false)} kind="clientes" />

      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => { if (!o) setDeleteTarget(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Tem certeza da exclusão?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTarget ? `O cliente "${deleteTarget.nome}" será removido em definitivo.` : ""}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Não</AlertDialogCancel>
            <AlertDialogAction
              disabled={deleting}
              onClick={async (e) => {
                e.preventDefault();
                if (!deleteTarget) return;
                setDeleting(true);
                try {
                  await actions.removeCliente(deleteTarget.id);
                  setDeleteTarget(null);
                  setExpandedId((id) => (id === deleteTarget.id ? null : id));
                  setEditingId((id) => (id === deleteTarget.id ? null : id));
                } catch (err: any) {
                  alert(err?.message ?? "Falha ao excluir");
                } finally { setDeleting(false); }
              }}
            >
              {deleting ? "Excluindo…" : "Sim"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

    </div>
  );
}

function Field({ label, value }: { label: string; value?: string | number | null }) {
  const v = value === 0 || value ? String(value) : "—";
  return (
    <div>
      <div className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="text-sm">{v}</div>
    </div>
  );
}

const ACCEPT_ATTACH = ".pdf,.png,.jpg,.jpeg,.doc,.docx,.xls,.xlsx,.csv";

function EditField({
  label, value, onChange, type = "text", as = "input", options, readOnly,
}: {
  label: string; value: string; onChange: (v: string) => void;
  type?: string; as?: "input" | "select"; readOnly?: boolean;
  options?: { value: string; label: string }[];
}) {
  return (
    <div>
      <Label>{label}</Label>
      {as === "select" ? (
        <Select value={value} onChange={(e) => onChange(e.target.value)}>
          <option value="">Selecionar…</option>
          {options?.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </Select>
      ) : (
        <Input type={type} value={value} readOnly={readOnly}
          className={readOnly ? "bg-muted/40" : undefined}
          onChange={(e) => onChange(e.target.value)} />
      )}
    </div>
  );
}


function AnexosBlock({ clienteId }: { clienteId: string }) {
  const [items, setItems] = useState<Anexo[]>([]);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const reload = async () => {
    try { setItems(await listAnexos("cliente", clienteId)); } catch { /* noop */ }
  };
  useEffect(() => { reload(); /* eslint-disable-next-line */ }, [clienteId]);

  const onPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    if (files.length === 0) return;
    setBusy(true);
    try {
      for (const f of files) await uploadAnexo("cliente", clienteId, f);
      await reload();
    } catch (err: any) {
      alert(err?.message ?? "Falha ao anexar");
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const onOpen = async (a: Anexo) => {
    try { const url = await downloadAnexo(a); window.open(url, "_blank"); }
    catch (err: any) { alert(err?.message ?? "Falha ao abrir"); }
  };

  const onRemove = async (a: Anexo) => {
    if (!confirm(`Remover anexo ${a.nome}?`)) return;
    try { await removeAnexo(a); await reload(); }
    catch (err: any) { alert(err?.message ?? "Falha ao remover"); }
  };

  return (
    <section>
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Anexos</h4>
        <div>
          <input ref={fileRef} type="file" accept={ACCEPT_ATTACH} multiple className="hidden" onChange={onPick} />
          <Button type="button" size="sm" variant="secondary" disabled={busy}
            onClick={() => fileRef.current?.click()}>
            {busy ? "Enviando…" : "📎 Anexar"}
          </Button>
        </div>
      </div>
      <p className="text-[11px] text-muted-foreground mb-2">PDF, PNG, JPG, Word, Excel ou CSV — até 20MB.</p>
      {items.length === 0 ? (
        <p className="text-sm text-muted-foreground">Nenhum anexo.</p>
      ) : (
        <ul className="divide-y divide-border border border-border rounded-md">
          {items.map((a) => (
            <li key={a.id} className="flex items-center justify-between px-3 py-2 text-sm gap-2">
              <button type="button" onClick={() => onOpen(a)} className="text-left flex-1 truncate hover:underline">
                {a.nome}
                <span className="ml-2 text-xs text-muted-foreground">
                  {(a.tamanho / 1024).toFixed(0)} KB
                </span>
              </button>
              <button type="button" onClick={() => onRemove(a)} className="text-xs text-destructive hover:underline">
                Excluir
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function ClienteDetalhes({ cliente: c, produtoNome, produtos, editing: editingProp, onEditingChange }: {
  cliente: Cliente; produtoNome?: string; produtos: Produto[];
  editing?: boolean; onEditingChange?: (v: boolean) => void;
}) {
  const [editingState, setEditingState] = useState(false);
  const editing = editingProp ?? editingState;
  const setEditing = (v: boolean) => { onEditingChange ? onEditingChange(v) : setEditingState(v); };
  const [saving, setSaving] = useState(false);
  const [draft, setDraft] = useState<Partial<Cliente>>({});
  const [comissaoPct, setComissaoPct] = useState<string>("");

  useEffect(() => {
    if (!editing) { setDraft({}); setComissaoPct(""); return; }
    // Inicializa % de comissão a partir dos valores existentes ao entrar em edição
    const vc = Number(c.produtoValorContratado) || 0;
    const vk = Number(c.produtoValorComissao) || 0;
    setComissaoPct(vc > 0 && vk > 0 ? String(Number(((vk / vc) * 100).toFixed(4))) : "");
  }, [editing, c.id]);



  const v = (k: keyof Cliente): string => {
    const x = draft[k] !== undefined ? draft[k] : (c as any)[k];
    return x == null ? "" : String(x);
  };
  const set = (k: keyof Cliente, val: string) => setDraft((d) => ({ ...d, [k]: val as any }));
  const setNum = (k: keyof Cliente, val: string) =>
    setDraft((d) => ({ ...d, [k]: (val === "" ? undefined : Number(val)) as any }));

  const onSave = async () => {
    setSaving(true);
    try {
      await actions.updateCliente(c.id, draft);
      setEditing(false);
      setDraft({});
    } catch (err: any) {
      alert(err?.message ?? "Falha ao salvar");
    } finally { setSaving(false); }
  };

  const endereco = [c.endereco, c.numero].filter(Boolean).join(", ") + (c.complemento ? ` — ${c.complemento}` : "");
  const prodOptions = useMemo(() => {
    const cat = (draft.produtoCategoria ?? c.produtoCategoria) as string | undefined;
    return produtos
      .filter((p) => (!cat || p.categoria === cat) && (p.tipoPessoa === c.tipo || p.tipoPessoa === "AMBOS"))
      .map((p) => ({ value: p.id, label: p.nome }));
  }, [produtos, c.tipo, c.produtoCategoria, draft.produtoCategoria]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <h3 className="text-sm font-semibold">Detalhes do cliente</h3>
        <div className="flex gap-2">
          {!editing ? (
            <Button type="button" size="sm" variant="secondary" onClick={() => setEditing(true)}>
              ✎ Editar
            </Button>
          ) : (
            <>
              <Button type="button" size="sm" variant="secondary"
                onClick={() => { setEditing(false); setDraft({}); }} disabled={saving}>
                Cancelar
              </Button>
              <Button type="button" size="sm" onClick={onSave} disabled={saving}>
                {saving ? "Salvando…" : "💾 Salvar"}
              </Button>
            </>
          )}
        </div>
      </div>

      <section>
        <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">
          {c.tipo === "PF" ? "Dados pessoais" : "Dados da empresa"}
        </h4>
        {c.tipo === "PF" ? (
          editing ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <EditField label="Nome completo" value={v("nome")} onChange={(x) => set("nome", x)} />
              <EditField label="CPF" value={v("cpfCnpj")} onChange={(x) => set("cpfCnpj", x)} />
              <EditField label="Data de nascimento" type="date" value={v("dataNascimento")} onChange={(x) => set("dataNascimento", x)} />
              <EditField label="Estado civil" as="select" value={v("estadoCivil")} onChange={(x) => set("estadoCivil", x)}
                options={[
                  { value: "Solteiro", label: "Solteiro(a)" }, { value: "Casado", label: "Casado(a)" },
                  { value: "Divorciado", label: "Divorciado(a)" }, { value: "Viúvo", label: "Viúvo(a)" },
                  { value: "União Estável", label: "União Estável" },
                ]} />
              <EditField label="Telefone" value={v("telefone")} onChange={(x) => set("telefone", x)} />
              <EditField label="Email" type="email" value={v("email")} onChange={(x) => set("email", x)} />
              <EditField label="Contato de recado" value={v("contatoRecado")} onChange={(x) => set("contatoRecado", x)} />
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <Field label="Nome completo" value={c.nome} />
              <Field label="CPF" value={c.cpfCnpj} />
              <Field label="Data de nascimento" value={c.dataNascimento ? fmtDate(c.dataNascimento) : undefined} />
              <Field label="Estado civil" value={c.estadoCivil} />
              <Field label="Telefone" value={c.telefone} />
              <Field label="Email" value={c.email} />
              <Field label="Contato de recado" value={c.contatoRecado} />
            </div>
          )
        ) : (
          editing ? (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <EditField label="Razão social" value={v("razaoSocial") || v("nome")} onChange={(x) => { set("razaoSocial", x); set("nome", x); }} />
                <EditField label="Nome fantasia" value={v("nomeFantasia")} onChange={(x) => set("nomeFantasia", x)} />
                <EditField label="CNPJ" value={v("cpfCnpj")} onChange={(x) => set("cpfCnpj", x)} />
                <EditField label="Inscrição estadual" value={v("inscricaoEstadual")} onChange={(x) => set("inscricaoEstadual", x)} />
                <EditField label="Inscrição municipal" value={v("inscricaoMunicipal")} onChange={(x) => set("inscricaoMunicipal", x)} />
                <EditField label="Telefone comercial" value={v("telefoneComercial") || v("telefone")} onChange={(x) => { set("telefoneComercial", x); set("telefone", x); }} />
                <EditField label="Email" type="email" value={v("email")} onChange={(x) => set("email", x)} />
              </div>
              <div className="mt-3">
                <h5 className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground mb-2">Representante</h5>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <EditField label="Nome" value={v("repNome")} onChange={(x) => set("repNome", x)} />
                  <EditField label="CPF" value={v("repCpf")} onChange={(x) => set("repCpf", x)} />
                  <EditField label="Data de nascimento" type="date" value={v("repDataNascimento")} onChange={(x) => set("repDataNascimento", x)} />
                  <EditField label="Telefone" value={v("repTelefone")} onChange={(x) => set("repTelefone", x)} />
                  <EditField label="Contato de recado" value={v("contatoRecado")} onChange={(x) => set("contatoRecado", x)} />
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <Field label="Razão social" value={c.razaoSocial || c.nome} />
                <Field label="Nome fantasia" value={c.nomeFantasia} />
                <Field label="CNPJ" value={c.cpfCnpj} />
                <Field label="Inscrição estadual" value={c.inscricaoEstadual} />
                <Field label="Inscrição municipal" value={c.inscricaoMunicipal} />
                <Field label="Telefone comercial" value={c.telefoneComercial || c.telefone} />
                <Field label="Email" value={c.email} />
              </div>
              {(c.repNome || c.repCpf || c.repTelefone) && (
                <div className="mt-3">
                  <h5 className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground mb-2">Representante</h5>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    <Field label="Nome" value={c.repNome} />
                    <Field label="CPF" value={c.repCpf} />
                    <Field label="Data de nascimento" value={c.repDataNascimento ? fmtDate(c.repDataNascimento) : undefined} />
                    <Field label="Telefone" value={c.repTelefone} />
                    <Field label="Contato de recado" value={c.contatoRecado} />
                  </div>
                </div>
              )}
            </>
          )
        )}
      </section>

      <section>
        <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">Endereço</h4>
        {editing ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <EditField label="CEP" value={v("cep")} onChange={(x) => set("cep", x)} />
            <EditField label="Cidade" value={v("cidade")} onChange={(x) => set("cidade", x)} />
            <EditField label="Endereço" value={v("endereco")} onChange={(x) => set("endereco", x)} />
            <EditField label="Número" value={v("numero")} onChange={(x) => set("numero", x)} />
            <EditField label="Complemento" value={v("complemento")} onChange={(x) => set("complemento", x)} />
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <Field label="CEP" value={c.cep} />
            <Field label="Cidade" value={c.cidade} />
            <Field label="Endereço" value={endereco.trim() ? endereco : undefined} />
          </div>
        )}
      </section>

      {(c.produtoCategoria || editing) && (
        <section>
          <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">
            Produto contratado{c.produtoCategoria ? ` — ${c.produtoCategoria === "seguro" ? "Seguro" : "Consórcio"}` : ""}
          </h4>
          {editing ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <EditField label="Categoria" as="select" value={v("produtoCategoria")}
                onChange={(x) => { set("produtoCategoria", x); set("produtoId", ""); }}
                options={[{ value: "seguro", label: "Seguro" }, { value: "consorcio", label: "Consórcio" }]} />
              <EditField label="Produto" as="select" value={v("produtoId")} onChange={(x) => set("produtoId", x)}
                options={prodOptions} />
              <EditField label="Valor contratado" type="number" value={v("produtoValorContratado")}
                onChange={(x) => {
                  setNum("produtoValorContratado", x);
                  const vc = Number(x) || 0;
                  const pct = Number(comissaoPct) || 0;
                  setDraft((d) => ({ ...d, produtoValorComissao: pct > 0 && vc > 0 ? vc * pct / 100 : undefined }));
                }} />
              <EditField label="Qtd. parcelas" type="number" value={v("produtoQtdParcelas")} onChange={(x) => setNum("produtoQtdParcelas", x)} />
              <EditField label="Valor da parcela" type="number" value={v("produtoValorParcela")} onChange={(x) => setNum("produtoValorParcela", x)} />
              <EditField label="Total das parcelas" type="number" value={v("produtoValorTotalParcelas")} onChange={(x) => setNum("produtoValorTotalParcelas", x)} />
              <EditField label="Comissão (%)" type="number" value={comissaoPct}
                onChange={(x) => {
                  setComissaoPct(x);
                  const pct = Number(x) || 0;
                  const vc = Number(draft.produtoValorContratado ?? c.produtoValorContratado) || 0;
                  setDraft((d) => ({ ...d, produtoValorComissao: pct > 0 && vc > 0 ? vc * pct / 100 : undefined }));
                }} />
              <EditField label="Valor total da comissão" value={
                (() => {
                  const val = draft.produtoValorComissao !== undefined ? draft.produtoValorComissao : c.produtoValorComissao;
                  return val != null ? fmtBRL(Number(val)) : "";
                })()
              } onChange={() => {}} readOnly />

              {(draft.produtoCategoria ?? c.produtoCategoria) === "consorcio" && (
                <>
                  <EditField label="Data da assembleia" type="date" value={v("produtoDataAssembleia")} onChange={(x) => set("produtoDataAssembleia", x)} />
                  <EditField label="Resultado da assembleia" as="select" value={v("produtoResultadoAssembleia")} onChange={(x) => set("produtoResultadoAssembleia", x)}
                    options={[
                      { value: "Não contemplado", label: "Não contemplado" },
                      { value: "Contemplado por sorteio", label: "Contemplado por sorteio" },
                      { value: "Contemplado por lance", label: "Contemplado por lance" },
                      { value: "Aguardando", label: "Aguardando" },
                    ]} />
                </>
              )}
            </div>
          ) : c.produtoCategoria ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <Field label="Produto" value={produtoNome} />
              <Field label="Valor contratado" value={c.produtoValorContratado != null ? fmtBRL(c.produtoValorContratado) : undefined} />
              <Field label="Qtd. parcelas" value={c.produtoQtdParcelas} />
              <Field label="Valor da parcela" value={c.produtoValorParcela != null ? fmtBRL(c.produtoValorParcela) : undefined} />
              <Field label="Total das parcelas" value={c.produtoValorTotalParcelas != null ? fmtBRL(c.produtoValorTotalParcelas) : undefined} />
              <Field label="Comissão" value={c.produtoValorComissao != null ? fmtBRL(c.produtoValorComissao) : undefined} />
              {c.produtoCategoria === "consorcio" && (
                <>
                  <Field label="Data da assembleia" value={c.produtoDataAssembleia ? fmtDate(c.produtoDataAssembleia) : undefined} />
                  <Field label="Resultado da assembleia" value={c.produtoResultadoAssembleia} />
                </>
              )}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">Nenhum produto vinculado.</p>
          )}
        </section>
      )}

      <AnexosBlock clienteId={c.id} />
    </div>
  );
}

type FormState = {

  tipo: "PF" | "PJ";
  // comuns
  email: string;
  cep: string;
  endereco: string;
  numero: string;
  complemento: string;
  cidade: string;
  // PF
  nome: string;
  cpf: string;
  dataNascimento: string;
  estadoCivil: string;
  telefone: string;
  contatoRecado: string;
  // PJ
  razaoSocial: string;
  nomeFantasia: string;
  cnpj: string;
  inscricaoEstadual: string;
  inscricaoMunicipal: string;
  telefoneComercial: string;
  repNome: string;
  repCpf: string;
  repDataNascimento: string;
  repTelefone: string;
};

const EMPTY: FormState = {
  tipo: "PF", email: "", cep: "", endereco: "", numero: "", complemento: "", cidade: "",
  nome: "", cpf: "", dataNascimento: "", estadoCivil: "", telefone: "", contatoRecado: "",
  razaoSocial: "", nomeFantasia: "", cnpj: "", inscricaoEstadual: "", inscricaoMunicipal: "",
  telefoneComercial: "", repNome: "", repCpf: "", repDataNascimento: "", repTelefone: "",
};

type ProdState = {
  categoria: "" | "seguro" | "consorcio";
  produtoId: string;
  valorContratado: string;
  qtdParcelas: string;
  valorParcela: string;
  comissaoPct: string;
  dataAssembleia: string;
  resultadoAssembleia: string;
};
const EMPTY_PROD: ProdState = {
  categoria: "", produtoId: "", valorContratado: "", qtdParcelas: "",
  valorParcela: "", comissaoPct: "", dataAssembleia: "", resultadoAssembleia: "",
};


function NovoClienteModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [f, setF] = useState<FormState>(EMPTY);
  const [p, setP] = useState<ProdState>(EMPTY_PROD);
  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [saving, setSaving] = useState(false);
  const upd = <K extends keyof FormState>(k: K, v: FormState[K]) => setF((s) => ({ ...s, [k]: v }));
  const updP = <K extends keyof ProdState>(k: K, v: ProdState[K]) => setP((s) => ({ ...s, [k]: v }));

  useEffect(() => {
    if (!open) return;
    listProdutos({ tipoPessoa: f.tipo }).then(setProdutos).catch(() => setProdutos([]));
    updP("produtoId", "");
  }, [open, f.tipo, p.categoria]);

  const produtosFiltrados = useMemo(
    () => produtos.filter((x) => !p.categoria || x.categoria === p.categoria),
    [produtos, p.categoria],
  );

  const valorTotalParcelas = useMemo(() => {
    const q = Number(p.qtdParcelas) || 0;
    const vp = Number(p.valorParcela) || 0;
    return q * vp;
  }, [p.qtdParcelas, p.valorParcela]);

  const valorComissaoCalc = useMemo(() => {
    const vc = Number(p.valorContratado) || 0;
    const pct = Number(p.comissaoPct) || 0;
    return vc * pct / 100;
  }, [p.valorContratado, p.comissaoPct]);


  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const nomePrincipal = f.tipo === "PF" ? f.nome : (f.razaoSocial || f.nomeFantasia);
    if (!nomePrincipal) return;
    const num = (s: string): number | undefined => {
      const n = Number(s);
      return s !== "" && Number.isFinite(n) ? n : undefined;
    };
    setSaving(true);
    try {
      await actions.addCliente({
        nome: nomePrincipal,
        tipo: f.tipo,
        cpfCnpj: f.tipo === "PF" ? f.cpf : f.cnpj,
        email: f.email,
        telefone: f.tipo === "PF" ? f.telefone : f.telefoneComercial,
        cidade: f.cidade,
        observacao: undefined,
        dataNascimento: f.tipo === "PF" ? f.dataNascimento : undefined,
        estadoCivil: f.tipo === "PF" ? f.estadoCivil : undefined,
        contatoRecado: f.contatoRecado,
        cep: f.cep, endereco: f.endereco, numero: f.numero, complemento: f.complemento,
        razaoSocial: f.tipo === "PJ" ? f.razaoSocial : undefined,
        nomeFantasia: f.tipo === "PJ" ? f.nomeFantasia : undefined,
        inscricaoEstadual: f.tipo === "PJ" ? f.inscricaoEstadual : undefined,
        inscricaoMunicipal: f.tipo === "PJ" ? f.inscricaoMunicipal : undefined,
        telefoneComercial: f.tipo === "PJ" ? f.telefoneComercial : undefined,
        repNome: f.tipo === "PJ" ? f.repNome : undefined,
        repCpf: f.tipo === "PJ" ? f.repCpf : undefined,
        repDataNascimento: f.tipo === "PJ" ? f.repDataNascimento : undefined,
        repTelefone: f.tipo === "PJ" ? f.repTelefone : undefined,
        produtoId: p.categoria ? (p.produtoId || undefined) : undefined,
        produtoCategoria: p.categoria || undefined,
        produtoValorContratado: p.categoria ? num(p.valorContratado) : undefined,
        produtoQtdParcelas: p.categoria ? num(p.qtdParcelas) : undefined,
        produtoValorParcela: p.categoria ? num(p.valorParcela) : undefined,
        produtoValorTotalParcelas: p.categoria && valorTotalParcelas > 0 ? valorTotalParcelas : undefined,
        produtoValorComissao: p.categoria && valorComissaoCalc > 0 ? valorComissaoCalc : undefined,
        produtoDataAssembleia: p.categoria === "consorcio" ? (p.dataAssembleia || undefined) : undefined,
        produtoResultadoAssembleia: p.categoria === "consorcio" ? (p.resultadoAssembleia || undefined) : undefined,
      });
      setF(EMPTY);
      setP(EMPTY_PROD);
      onClose();
    } finally {
      setSaving(false);
    }
  };

  const TipoToggle = (
    <div className="inline-flex rounded-md border border-border overflow-hidden">
      {(["PF", "PJ"] as const).map((t) => (
        <button
          key={t}
          type="button"
          onClick={() => upd("tipo", t)}
          className={`px-4 py-1.5 text-sm font-medium transition-colors ${
            f.tipo === t ? "bg-primary text-primary-foreground" : "bg-background hover:bg-muted"
          }`}
        >
          {t === "PF" ? "Pessoa Física" : "Pessoa Jurídica"}
        </button>
      ))}
    </div>
  );

  return (
    <Modal open={open} onClose={onClose} title="Novo cliente">
      <form onSubmit={submit} className="space-y-5 max-h-[70vh] overflow-y-auto pr-1">
        <div>
          <Label>Tipo de pessoa</Label>
          <div className="mt-1">{TipoToggle}</div>
        </div>

        {f.tipo === "PF" ? (
          <section className="space-y-3">
            <h3 className="text-sm font-semibold text-muted-foreground border-b border-border pb-1">Dados pessoais</h3>
            <div>
              <Label>Nome completo *</Label>
              <Input value={f.nome} onChange={(e) => upd("nome", e.target.value)} required />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>CPF</Label>
                <Input value={f.cpf} onChange={(e) => upd("cpf", e.target.value)} />
              </div>
              <div>
                <Label>Data de nascimento</Label>
                <Input type="date" value={f.dataNascimento} onChange={(e) => upd("dataNascimento", e.target.value)} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Estado civil</Label>
                <Select value={f.estadoCivil} onChange={(e) => upd("estadoCivil", e.target.value)}>
                  <option value="">Selecionar…</option>
                  <option value="Solteiro">Solteiro(a)</option>
                  <option value="Casado">Casado(a)</option>
                  <option value="Divorciado">Divorciado(a)</option>
                  <option value="Viúvo">Viúvo(a)</option>
                  <option value="União Estável">União Estável</option>
                </Select>
              </div>
              <div>
                <Label>Telefone (com DDD)</Label>
                <Input value={f.telefone} onChange={(e) => upd("telefone", e.target.value)} placeholder="(11) 99999-0000" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Email</Label>
                <Input type="email" value={f.email} onChange={(e) => upd("email", e.target.value)} />
              </div>
              <div>
                <Label>Contato de recado</Label>
                <Input value={f.contatoRecado} onChange={(e) => upd("contatoRecado", e.target.value)} placeholder="Nome e telefone" />
              </div>
            </div>
          </section>
        ) : (
          <section className="space-y-3">
            <h3 className="text-sm font-semibold text-muted-foreground border-b border-border pb-1">Dados da empresa</h3>
            <div>
              <Label>Razão social *</Label>
              <Input value={f.razaoSocial} onChange={(e) => upd("razaoSocial", e.target.value)} required />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Nome fantasia</Label>
                <Input value={f.nomeFantasia} onChange={(e) => upd("nomeFantasia", e.target.value)} />
              </div>
              <div>
                <Label>CNPJ</Label>
                <Input value={f.cnpj} onChange={(e) => upd("cnpj", e.target.value)} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Inscrição estadual</Label>
                <Input value={f.inscricaoEstadual} onChange={(e) => upd("inscricaoEstadual", e.target.value)} />
              </div>
              <div>
                <Label>Inscrição municipal</Label>
                <Input value={f.inscricaoMunicipal} onChange={(e) => upd("inscricaoMunicipal", e.target.value)} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Telefone comercial (com DDD)</Label>
                <Input value={f.telefoneComercial} onChange={(e) => upd("telefoneComercial", e.target.value)} />
              </div>
              <div>
                <Label>Email</Label>
                <Input type="email" value={f.email} onChange={(e) => upd("email", e.target.value)} />
              </div>
            </div>

            <h3 className="text-sm font-semibold text-muted-foreground border-b border-border pb-1 pt-2">Representante</h3>
            <div>
              <Label>Nome completo</Label>
              <Input value={f.repNome} onChange={(e) => upd("repNome", e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>CPF</Label>
                <Input value={f.repCpf} onChange={(e) => upd("repCpf", e.target.value)} />
              </div>
              <div>
                <Label>Data de nascimento</Label>
                <Input type="date" value={f.repDataNascimento} onChange={(e) => upd("repDataNascimento", e.target.value)} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Telefone (com DDD)</Label>
                <Input value={f.repTelefone} onChange={(e) => upd("repTelefone", e.target.value)} />
              </div>
              <div>
                <Label>Contato de recado</Label>
                <Input value={f.contatoRecado} onChange={(e) => upd("contatoRecado", e.target.value)} />
              </div>
            </div>
          </section>
        )}

        <section className="space-y-3">
          <h3 className="text-sm font-semibold text-muted-foreground border-b border-border pb-1">Endereço</h3>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label>CEP</Label>
              <Input value={f.cep} onChange={(e) => upd("cep", e.target.value)} />
            </div>
            <div className="col-span-2">
              <Label>Cidade</Label>
              <Input value={f.cidade} onChange={(e) => upd("cidade", e.target.value)} />
            </div>
          </div>
          <div>
            <Label>Endereço</Label>
            <Input value={f.endereco} onChange={(e) => upd("endereco", e.target.value)} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Número</Label>
              <Input value={f.numero} onChange={(e) => upd("numero", e.target.value)} />
            </div>
            <div>
              <Label>Complemento</Label>
              <Input value={f.complemento} onChange={(e) => upd("complemento", e.target.value)} />
            </div>
          </div>
        </section>

        <section className="space-y-3">
          <h3 className="text-sm font-semibold text-muted-foreground border-b border-border pb-1">
            Produto contratado <span className="font-normal text-xs">(opcional)</span>
          </h3>
          <div>
            <Label>Tipo de produto</Label>
            <div className="mt-1 inline-flex rounded-md border border-border overflow-hidden">
              {([
                { v: "", l: "Nenhum" },
                { v: "seguro", l: "Seguro" },
                { v: "consorcio", l: "Consórcio" },
              ] as const).map((opt) => (
                <button
                  key={opt.v}
                  type="button"
                  onClick={() => updP("categoria", opt.v as ProdState["categoria"])}
                  className={`px-4 py-1.5 text-sm font-medium ${
                    p.categoria === opt.v ? "bg-primary text-primary-foreground" : "bg-background hover:bg-muted"
                  }`}
                >
                  {opt.l}
                </button>
              ))}
            </div>
          </div>

          {p.categoria && (
            <>
              <div>
                <Label>
                  {p.categoria === "seguro" ? "Seguro" : "Consórcio"} ({f.tipo === "PF" ? "Pessoa Física" : "Pessoa Jurídica"})
                </Label>
                <Select value={p.produtoId} onChange={(e) => updP("produtoId", e.target.value)}>
                  <option value="">Selecionar…</option>
                  {produtosFiltrados.map((x) => (
                    <option key={x.id} value={x.id}>{x.nome}</option>
                  ))}
                </Select>
                {produtosFiltrados.length === 0 && (
                  <p className="text-xs text-muted-foreground mt-1">
                    Nenhum produto cadastrado para {f.tipo}. Peça ao administrador para cadastrar no catálogo.
                  </p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Valor total contratado (R$)</Label>
                  <Input type="number" step="0.01" value={p.valorContratado} onChange={(e) => updP("valorContratado", e.target.value)} />
                </div>
                <div>
                  <Label>Quantidade de parcelas</Label>
                  <Input type="number" min="1" value={p.qtdParcelas} onChange={(e) => updP("qtdParcelas", e.target.value)} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Valor da parcela (R$)</Label>
                  <Input type="number" step="0.01" value={p.valorParcela} onChange={(e) => updP("valorParcela", e.target.value)} />
                </div>
                <div>
                  <Label>Total das parcelas</Label>
                  <Input value={valorTotalParcelas ? fmtBRL(valorTotalParcelas) : ""} readOnly className="bg-muted/40" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Comissão (%)</Label>
                  <Input type="number" step="0.01" min="0" max="100" placeholder="Ex: 8"
                    value={p.comissaoPct} onChange={(e) => updP("comissaoPct", e.target.value)} />
                </div>
                <div>
                  <Label>Valor total da comissão</Label>
                  <Input value={valorComissaoCalc ? fmtBRL(valorComissaoCalc) : ""} readOnly className="bg-muted/40" />
                </div>
              </div>


              {p.categoria === "consorcio" && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Data da assembleia</Label>
                    <Input type="date" value={p.dataAssembleia} onChange={(e) => updP("dataAssembleia", e.target.value)} />
                  </div>
                  <div>
                    <Label>Resultado da assembleia</Label>
                    <Select value={p.resultadoAssembleia} onChange={(e) => updP("resultadoAssembleia", e.target.value)}>
                      <option value="">Selecionar…</option>
                      <option value="Não contemplado">Não contemplado</option>
                      <option value="Contemplado por sorteio">Contemplado por sorteio</option>
                      <option value="Contemplado por lance">Contemplado por lance</option>
                      <option value="Aguardando">Aguardando</option>
                    </Select>
                  </div>
                </div>
              )}
            </>
          )}
        </section>

        <div className="flex justify-end gap-2 pt-2 border-t border-border">
          <Button type="button" variant="secondary" onClick={onClose} disabled={saving}>Cancelar</Button>
          <Button type="submit" disabled={saving}>{saving ? "Salvando…" : "Salvar cliente"}</Button>
        </div>
      </form>
    </Modal>
  );
}
