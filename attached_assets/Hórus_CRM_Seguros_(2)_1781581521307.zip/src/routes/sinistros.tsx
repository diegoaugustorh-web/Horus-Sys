import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useStore, actions, fmtBRL, fmtDate, usePerms, type StatusSinistro } from "@/lib/store";
import { Button, Card, Input, Label, Modal, PageHeader, Select, StatusBadge, Textarea } from "@/components/AppShell";

export const Route = createFileRoute("/sinistros")({
  head: () => ({
    meta: [
      { title: "Sinistros — Hórus CRM" },
      { name: "description", content: "Abertura e acompanhamento de sinistros." },
    ],
  }),
  component: SinistrosPage,
});

const STATUS: StatusSinistro[] = ["Aberto", "Em Análise", "Aprovado", "Negado", "Pago"];

function SinistrosPage() {
  const { sinistros, apolices, clientes } = useStore();
  const { canManageSeguros } = usePerms();
  const [open, setOpen] = useState(false);
  const [filtro, setFiltro] = useState<"" | StatusSinistro>("");

  const cliMap = Object.fromEntries(clientes.map((c) => [c.id, c.nome]));
  const apMap = Object.fromEntries(apolices.map((a) => [a.id, a]));

  const filtrados = sinistros.filter((s) => !filtro || s.status === filtro);

  const stats = {
    abertos: sinistros.filter((s) => s.status === "Aberto").length,
    analise: sinistros.filter((s) => s.status === "Em Análise").length,
    pagos: sinistros.filter((s) => s.status === "Pago").length,
    valorTotal: sinistros.reduce((s, x) => s + x.valorEstimado, 0),
  };

  return (
    <div className="p-6 lg:p-8">
      <PageHeader
        title="Sinistros"
        subtitle="Controle e acompanhamento de eventos cobertos"
        action={canManageSeguros ? <Button onClick={() => setOpen(true)}>+ Abrir sinistro</Button> : null}
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Card className="p-4"><div className="text-xs text-muted-foreground uppercase font-medium">Abertos</div><div className="text-2xl font-semibold mt-1">{stats.abertos}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground uppercase font-medium">Em análise</div><div className="text-2xl font-semibold mt-1">{stats.analise}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground uppercase font-medium">Pagos</div><div className="text-2xl font-semibold mt-1">{stats.pagos}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground uppercase font-medium">Volume total</div><div className="text-2xl font-semibold mt-1">{fmtBRL(stats.valorTotal)}</div></Card>
      </div>

      <Card className="p-4 mb-4 flex gap-3">
        <div className="w-48">
          <Select value={filtro} onChange={(e) => setFiltro(e.target.value as "" | StatusSinistro)}>
            <option value="">Todos os status</option>
            {STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
          </Select>
        </div>
      </Card>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-muted-foreground border-b border-border bg-muted/40">
                <th className="font-medium px-4 py-3">Protocolo</th>
                <th className="font-medium px-4 py-3">Cliente / Apólice</th>
                <th className="font-medium px-4 py-3">Ocorrência</th>
                <th className="font-medium px-4 py-3">Descrição</th>
                <th className="font-medium px-4 py-3 text-right">Valor</th>
                <th className="font-medium px-4 py-3">Status</th>
                <th className="font-medium px-4 py-3 text-right">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filtrados.map((s) => {
                const ap = apMap[s.apoliceId];
                return (
                  <tr key={s.id} className="border-b border-border/50 last:border-0 hover:bg-muted/30 align-top">
                    <td className="px-4 py-3 font-mono text-xs">{s.protocolo}</td>
                    <td className="px-4 py-3">
                      <div className="font-medium">{ap ? cliMap[ap.clienteId] : "—"}</div>
                      <div className="text-xs text-muted-foreground font-mono">{ap?.numero || "—"} · {ap?.ramo}</div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground text-xs">{fmtDate(s.dataOcorrencia)}</td>
                    <td className="px-4 py-3 max-w-[280px]">{s.descricao}</td>
                    <td className="px-4 py-3 text-right">{fmtBRL(s.valorEstimado)}</td>
                    <td className="px-4 py-3">
                      {canManageSeguros ? (
                        <Select value={s.status} onChange={(e) => actions.updateSinistroStatus(s.id, e.target.value as StatusSinistro)} className="h-7 text-xs py-0">
                          {STATUS.map((x) => <option key={x} value={x}>{x}</option>)}
                        </Select>
                      ) : (
                        <StatusBadge status={s.status} />
                      )}
                    </td>
                    <td className="px-4 py-3 text-right">
                      {canManageSeguros && (
                        <Button variant="danger" size="sm" onClick={() => confirm(`Excluir ${s.protocolo}?`) && actions.removeSinistro(s.id)}>Excluir</Button>
                      )}
                    </td>
                  </tr>
                );
              })}
              {filtrados.length === 0 && (
                <tr><td colSpan={7} className="px-4 py-10 text-center text-muted-foreground text-sm">Nenhum sinistro encontrado.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      <NovoSinistroModal open={open} onClose={() => setOpen(false)} />
    </div>
  );
}

function NovoSinistroModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { apolices, clientes } = useStore();
  const cliMap = Object.fromEntries(clientes.map((c) => [c.id, c.nome]));
  const ano = new Date().getFullYear();
  const [form, setForm] = useState({
    protocolo: `SIN-${ano}-${String(Math.floor(Math.random() * 9999)).padStart(4, "0")}`,
    apoliceId: "",
    dataOcorrencia: new Date().toISOString().slice(0, 10),
    descricao: "",
    valorEstimado: 0,
    status: "Aberto" as StatusSinistro,
  });
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.apoliceId) return;
    actions.addSinistro(form);
    onClose();
  };
  return (
    <Modal open={open} onClose={onClose} title="Abrir sinistro">
      <form onSubmit={submit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Protocolo</Label><Input value={form.protocolo} onChange={(e) => setForm({ ...form, protocolo: e.target.value })} /></div>
          <div>
            <Label>Apólice</Label>
            <Select value={form.apoliceId} onChange={(e) => setForm({ ...form, apoliceId: e.target.value })} required>
              <option value="">Selecione…</option>
              {apolices.map((a) => <option key={a.id} value={a.id}>{a.numero} — {cliMap[a.clienteId]}</option>)}
            </Select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Data da ocorrência</Label><Input type="date" value={form.dataOcorrencia} onChange={(e) => setForm({ ...form, dataOcorrencia: e.target.value })} /></div>
          <div><Label>Valor estimado (R$)</Label><Input type="number" step="0.01" value={form.valorEstimado} onChange={(e) => setForm({ ...form, valorEstimado: Number(e.target.value) })} /></div>
        </div>
        <div>
          <Label>Descrição</Label>
          <Textarea rows={3} value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} required />
        </div>
        <div>
          <Label>Status inicial</Label>
          <Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as StatusSinistro })}>
            {STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
          </Select>
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="secondary" onClick={onClose}>Cancelar</Button>
          <Button type="submit">Abrir sinistro</Button>
        </div>
      </form>
    </Modal>
  );
}

void StatusBadge;
