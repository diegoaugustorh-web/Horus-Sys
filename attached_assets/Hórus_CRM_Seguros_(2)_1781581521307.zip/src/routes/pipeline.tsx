import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useStore, actions, fmtBRL, usePerms, type EstagioPipeline, type RamoSeguro, type Produto, type Cliente } from "@/lib/store";
import { Button, Card, Input, Label, Modal, PageHeader, Select } from "@/components/AppShell";
import { ImportModal } from "@/components/ImportModal";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/pipeline")({
  head: () => ({
    meta: [
      { title: "Pipeline — Hórus CRM" },
      { name: "description", content: "Funil de vendas de seguros: leads, cotações e propostas." },
    ],
  }),
  component: PipelinePage,
});

const ESTAGIOS: { id: EstagioPipeline; cor: string }[] = [
  { id: "Lead", cor: "bg-slate-400" },
  { id: "Cotação", cor: "bg-info" },
  { id: "Proposta", cor: "bg-primary" },
  { id: "Negociação", cor: "bg-accent" },
  { id: "Ganho", cor: "bg-success" },
  { id: "Perdido", cor: "bg-destructive" },
];

const RAMOS: RamoSeguro[] = ["Auto", "Vida", "Residencial", "Empresarial", "Saúde", "Viagem"];

function PipelinePage() {
  const { oportunidades } = useStore();
  const { canDeletePipeline } = usePerms();
  const [open, setOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [dragId, setDragId] = useState<string | null>(null);

  const ativos = oportunidades.filter((o) => o.estagio !== "Ganho" && o.estagio !== "Perdido");
  const total = ativos.reduce((s, o) => s + o.valorEstimado, 0);

  return (
    <div className="p-6 lg:p-8">
      <PageHeader
        title="Pipeline de Vendas"
        subtitle={`${ativos.length} oportunidades ativas · ${fmtBRL(total)} em negociação`}
        action={
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => setImportOpen(true)}>↑ Importar</Button>
            <Button onClick={() => setOpen(true)}>+ Nova oportunidade</Button>
          </div>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {ESTAGIOS.map((est) => {
          const items = oportunidades.filter((o) => o.estagio === est.id);
          const subtotal = items.reduce((s, o) => s + o.valorEstimado, 0);
          return (
            <div
              key={est.id}
              className="bg-muted/40 rounded-lg p-3 min-h-[400px] flex flex-col"
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => { if (dragId) { actions.moveOportunidade(dragId, est.id); setDragId(null); } }}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${est.cor}`} />
                  <span className="text-xs font-semibold text-foreground">{est.id}</span>
                </div>
                <span className="text-xs text-muted-foreground">{items.length}</span>
              </div>
              <div className="text-xs text-muted-foreground mb-3">{fmtBRL(subtotal)}</div>
              <div className="space-y-2 flex-1">
                {items.map((o) => (
                  <div
                    key={o.id}
                    draggable
                    onDragStart={() => setDragId(o.id)}
                    className="bg-card rounded-md p-3 border border-border shadow-card cursor-grab active:cursor-grabbing hover:border-primary/40 transition-colors"
                  >
                    <div className="text-sm font-medium text-foreground">{o.cliente}</div>
                    <div className="text-xs text-muted-foreground mt-0.5">{o.ramo}</div>
                    <div className="text-sm font-semibold text-primary mt-2">{fmtBRL(o.valorEstimado)}</div>
                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-border">
                      <span className="text-[11px] text-muted-foreground">👤 {o.responsavel}</span>
                      {canDeletePipeline && (
                        <button onClick={() => actions.removeOportunidade(o.id)} className="text-xs text-muted-foreground hover:text-destructive">×</button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <Card className="mt-6 p-4 text-xs text-muted-foreground">
        💡 Arraste os cards entre as colunas para mover oportunidades de estágio.
      </Card>

      <NovaOportunidadeModal open={open} onClose={() => setOpen(false)} />
      <ImportModal open={importOpen} onClose={() => setImportOpen(false)} kind="pipeline" />
    </div>
  );
}

function NovaOportunidadeModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { clientes, userId } = useStore();
  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [clienteId, setClienteId] = useState<string>("");
  const [produtoId, setProdutoId] = useState<string>("");
  const [form, setForm] = useState({
    ramo: "Auto" as RamoSeguro,
    valorEstimado: 0,
    qtdParcelas: 1,
    valorParcela: 0,
    comissaoPct: 0,
    estagio: "Lead" as EstagioPipeline,
    responsavel: "Ana",
    observacao: "",
    // reunião
    agendarReuniao: false,
    reuniaoModalidade: "Microsoft Teams" as "Microsoft Teams" | "Google Meet" | "Presencial" | "Telefone",
    reuniaoData: "",
    reuniaoLink: "",
  });

  useEffect(() => {
    if (!open) return;
    supabase.from("produtos").select("*").eq("ativo", true).order("nome").then(({ data }) => {
      setProdutos((data ?? []).map((r: any) => ({ id: r.id, nome: r.nome, categoria: r.categoria, tipoPessoa: r.tipo_pessoa, ativo: r.ativo })));
    });
  }, [open]);

  const cliente: Cliente | undefined = useMemo(() => clientes.find((c) => c.id === clienteId), [clientes, clienteId]);
  const produto = useMemo(() => produtos.find((p) => p.id === produtoId), [produtos, produtoId]);
  const valorTotal = form.qtdParcelas * form.valorParcela;
  const comissao = (valorTotal * form.comissaoPct) / 100;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cliente) { alert("Selecione um cliente"); return; }
    const detalhes = [
      produto ? `Produto: ${produto.nome}` : "",
      `Parcelas: ${form.qtdParcelas} x ${fmtBRL(form.valorParcela)}`,
      `Valor total: ${fmtBRL(valorTotal)}`,
      `Comissão: ${form.comissaoPct}% = ${fmtBRL(comissao)}`,
      form.agendarReuniao ? `Reunião ${form.reuniaoModalidade} em ${form.reuniaoData}${form.reuniaoLink ? ` — ${form.reuniaoLink}` : ""}` : "",
      form.observacao,
    ].filter(Boolean).join("\n");

    await actions.addOportunidade({
      cliente: cliente.nome,
      ramo: form.ramo,
      valorEstimado: form.valorEstimado || valorTotal,
      estagio: form.estagio,
      responsavel: form.responsavel,
      observacao: detalhes,
    });

    if (form.agendarReuniao && form.reuniaoData && userId) {
      await supabase.from("reunioes").insert({
        owner_id: userId,
        cliente_id: cliente.id,
        titulo: `Reunião — ${cliente.nome}`,
        data_hora: new Date(form.reuniaoData).toISOString(),
        tipo: "Reunião",
        modalidade: form.reuniaoModalidade,
        link_reuniao: form.reuniaoLink || null,
        observacoes: detalhes.slice(0, 4900),
      });
    }
    onClose();
  };

  const msgReuniao = () => {
    const quando = form.reuniaoData ? new Date(form.reuniaoData).toLocaleString("pt-BR") : "(definir)";
    return `Olá ${cliente?.nome ?? ""}, sua reunião está agendada para ${quando} via ${form.reuniaoModalidade}.${form.reuniaoLink ? ` Link: ${form.reuniaoLink}` : ""}`;
  };
  const notifWhatsApp = () => {
    if (!cliente) { alert("Selecione um cliente"); return; }
    const tel = (cliente.telefone || "").replace(/\D/g, "");
    if (!tel) { alert("Cliente sem telefone"); return; }
    window.open(`https://wa.me/${tel}?text=${encodeURIComponent(msgReuniao())}`, "_blank");
  };
  const notifEmail = () => {
    if (!cliente?.email) { alert("Cliente sem email"); return; }
    const subj = encodeURIComponent("Confirmação de reunião");
    const body = encodeURIComponent(msgReuniao());
    window.location.href = `mailto:${cliente.email}?subject=${subj}&body=${body}`;
  };

  return (
    <Modal open={open} onClose={onClose} title="Nova oportunidade">
      <form onSubmit={submit} className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
        <div>
          <Label>Cliente</Label>
          <Select value={clienteId} onChange={(e) => setClienteId(e.target.value)} required>
            <option value="">Selecione um cliente...</option>
            {clientes.map((c) => <option key={c.id} value={c.id}>{c.nome} — {c.cpfCnpj || c.email || c.telefone}</option>)}
          </Select>
          {cliente && (
            <div className="text-xs text-muted-foreground mt-1">
              {cliente.email} · {cliente.telefone} · {cliente.cidade}
            </div>
          )}
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Produto</Label>
            <Select value={produtoId} onChange={(e) => setProdutoId(e.target.value)}>
              <option value="">Selecione...</option>
              {produtos.map((p) => <option key={p.id} value={p.id}>{p.nome} ({p.categoria})</option>)}
            </Select>
          </div>
          <div>
            <Label>Ramo</Label>
            <Select value={form.ramo} onChange={(e) => setForm({ ...form, ramo: e.target.value as RamoSeguro })}>
              {RAMOS.map((r) => <option key={r} value={r}>{r}</option>)}
            </Select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Valor estimado (R$)</Label>
            <Input type="number" step="0.01" value={form.valorEstimado} onChange={(e) => setForm({ ...form, valorEstimado: Number(e.target.value) })} />
          </div>
          <div>
            <Label>Qtd. parcelas</Label>
            <Input type="number" min={1} value={form.qtdParcelas} onChange={(e) => setForm({ ...form, qtdParcelas: Number(e.target.value) })} />
          </div>
          <div>
            <Label>Valor da parcela (R$)</Label>
            <Input type="number" step="0.01" value={form.valorParcela} onChange={(e) => setForm({ ...form, valorParcela: Number(e.target.value) })} />
          </div>
          <div>
            <Label>Valor total (R$)</Label>
            <Input value={fmtBRL(valorTotal)} readOnly />
          </div>
          <div>
            <Label>% Comissão</Label>
            <Input type="number" step="0.01" value={form.comissaoPct} onChange={(e) => setForm({ ...form, comissaoPct: Number(e.target.value) })} />
          </div>
          <div>
            <Label>Comissão calculada</Label>
            <Input value={fmtBRL(comissao)} readOnly />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Estágio inicial</Label>
            <Select value={form.estagio} onChange={(e) => setForm({ ...form, estagio: e.target.value as EstagioPipeline })}>
              {ESTAGIOS.map((e) => <option key={e.id} value={e.id}>{e.id}</option>)}
            </Select>
          </div>
          <div>
            <Label>Responsável</Label>
            <Input value={form.responsavel} onChange={(e) => setForm({ ...form, responsavel: e.target.value })} />
          </div>
        </div>

        <div className="border-t border-border pt-3 space-y-3">
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={form.agendarReuniao} onChange={(e) => setForm({ ...form, agendarReuniao: e.target.checked })} />
            Agendar reunião
          </label>
          {form.agendarReuniao && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Modalidade</Label>
                  <Select value={form.reuniaoModalidade} onChange={(e) => setForm({ ...form, reuniaoModalidade: e.target.value as typeof form.reuniaoModalidade })}>
                    <option value="Microsoft Teams">Microsoft Teams</option>
                    <option value="Google Meet">Google Meet</option>
                    <option value="Presencial">Presencial</option>
                    <option value="Telefone">Telefone</option>
                  </Select>
                </div>
                <div>
                  <Label>Data e hora</Label>
                  <Input type="datetime-local" value={form.reuniaoData} onChange={(e) => setForm({ ...form, reuniaoData: e.target.value })} />
                </div>
              </div>
              {(form.reuniaoModalidade === "Microsoft Teams" || form.reuniaoModalidade === "Google Meet") && (
                <div>
                  <Label>Link da reunião (opcional)</Label>
                  <Input placeholder="https://..." value={form.reuniaoLink} onChange={(e) => setForm({ ...form, reuniaoLink: e.target.value })} />
                </div>
              )}
              <div className="flex gap-2">
                <Button type="button" variant="secondary" onClick={notifWhatsApp}>📱 Enviar WhatsApp</Button>
                <Button type="button" variant="secondary" onClick={notifEmail}>✉️ Enviar Email</Button>
              </div>
            </>
          )}
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="secondary" onClick={onClose}>Cancelar</Button>
          <Button type="submit">Criar oportunidade</Button>
        </div>
      </form>
    </Modal>
  );
}
