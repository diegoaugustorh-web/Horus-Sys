import { createFileRoute, Link } from "@tanstack/react-router";
import { useStore, fmtBRL, fmtDate } from "@/lib/store";
import { Card, PageHeader, StatusBadge } from "@/components/AppShell";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard — Hórus CRM" },
      { name: "description", content: "Visão geral da carteira: prêmios, renovações, sinistros e comissões." },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const { clientes, apolices, oportunidades, sinistros, comissoes } = useStore();

  const premioTotal = apolices.filter((a) => a.status === "Vigente").reduce((s, a) => s + a.premio, 0);
  const aRenovar = apolices.filter((a) => a.status === "A Renovar").length;
  const sinistrosAbertos = sinistros.filter((s) => s.status === "Aberto" || s.status === "Em Análise").length;
  const comissoesAReceber = comissoes.filter((c) => c.status === "A Receber" || c.status === "Atrasada").reduce((s, c) => s + c.valor, 0);
  const pipelineValor = oportunidades.filter((o) => o.estagio !== "Ganho" && o.estagio !== "Perdido").reduce((s, o) => s + o.valorEstimado, 0);
  const ganhoMes = oportunidades.filter((o) => o.estagio === "Ganho").reduce((s, o) => s + o.valorEstimado, 0);

  const kpis = [
    { label: "Prêmio anualizado", value: fmtBRL(premioTotal), hint: `${apolices.filter((a) => a.status === "Vigente").length} apólices vigentes`, accent: "primary" },
    { label: "A renovar", value: aRenovar, hint: "próximos 60 dias", accent: "warning" },
    { label: "Sinistros em aberto", value: sinistrosAbertos, hint: "aguardando análise", accent: "info" },
    { label: "Comissões a receber", value: fmtBRL(comissoesAReceber), hint: "incluindo atrasadas", accent: "success" },
    { label: "Pipeline ativo", value: fmtBRL(pipelineValor), hint: `${oportunidades.filter((o) => !["Ganho", "Perdido"].includes(o.estagio)).length} oportunidades`, accent: "primary" },
    { label: "Vendas ganhas", value: fmtBRL(ganhoMes), hint: "este período", accent: "success" },
  ];

  const proximosVencimentos = [...apolices]
    .filter((a) => a.status !== "Cancelada" && a.status !== "Vencida")
    .sort((a, b) => a.fim.localeCompare(b.fim))
    .slice(0, 5);

  const sinistrosRecentes = [...sinistros].sort((a, b) => b.abertoEm.localeCompare(a.abertoEm)).slice(0, 4);

  const clienteNome = (id: string) => clientes.find((c) => c.id === id)?.nome ?? "—";

  return (
    <div className="p-6 lg:p-8">
      <PageHeader title="Dashboard" subtitle={`Bem-vindo de volta. Você tem ${aRenovar} apólices para renovar e ${sinistrosAbertos} sinistros em aberto.`} />

      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-8">
        {kpis.map((k) => (
          <Card key={k.label} className="p-4">
            <div className="text-xs text-muted-foreground font-medium uppercase tracking-wide">{k.label}</div>
            <div className="text-2xl font-semibold text-foreground mt-2">{k.value}</div>
            <div className="text-xs text-muted-foreground mt-1">{k.hint}</div>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">Próximos vencimentos</h2>
            <Link to="/apolices" className="text-xs text-primary hover:underline">Ver todas →</Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-muted-foreground border-b border-border">
                  <th className="font-medium py-2">Apólice</th>
                  <th className="font-medium py-2">Cliente</th>
                  <th className="font-medium py-2">Ramo</th>
                  <th className="font-medium py-2">Vence em</th>
                  <th className="font-medium py-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {proximosVencimentos.map((a) => (
                  <tr key={a.id} className="border-b border-border/50 last:border-0">
                    <td className="py-2.5 font-mono text-xs">{a.numero}</td>
                    <td className="py-2.5">{clienteNome(a.clienteId)}</td>
                    <td className="py-2.5 text-muted-foreground">{a.ramo}</td>
                    <td className="py-2.5">{fmtDate(a.fim)}</td>
                    <td className="py-2.5"><StatusBadge status={a.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <Card className="p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">Sinistros recentes</h2>
            <Link to="/sinistros" className="text-xs text-primary hover:underline">Ver todos →</Link>
          </div>
          <ul className="space-y-3">
            {sinistrosRecentes.map((s) => {
              const ap = apolices.find((a) => a.id === s.apoliceId);
              return (
                <li key={s.id} className="border-l-2 border-primary/40 pl-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="font-mono text-xs text-muted-foreground">{s.protocolo}</div>
                    <StatusBadge status={s.status} />
                  </div>
                  <div className="text-sm mt-0.5">{s.descricao}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {ap ? clienteNome(ap.clienteId) : "—"} · {fmtBRL(s.valorEstimado)}
                  </div>
                </li>
              );
            })}
          </ul>
        </Card>
      </div>

      <div className="grid md:grid-cols-3 gap-4 mt-6">
        <Card className="p-5">
          <div className="text-xs text-muted-foreground uppercase font-medium tracking-wide">Clientes</div>
          <div className="text-3xl font-semibold mt-2">{clientes.length}</div>
          <Link to="/clientes" className="text-xs text-primary hover:underline mt-2 inline-block">Gerenciar →</Link>
        </Card>
        <Card className="p-5">
          <div className="text-xs text-muted-foreground uppercase font-medium tracking-wide">Apólices ativas</div>
          <div className="text-3xl font-semibold mt-2">{apolices.filter((a) => a.status === "Vigente").length}</div>
          <Link to="/apolices" className="text-xs text-primary hover:underline mt-2 inline-block">Ver carteira →</Link>
        </Card>
        <Card className="p-5">
          <div className="text-xs text-muted-foreground uppercase font-medium tracking-wide">Oportunidades</div>
          <div className="text-3xl font-semibold mt-2">{oportunidades.length}</div>
          <Link to="/pipeline" className="text-xs text-primary hover:underline mt-2 inline-block">Abrir pipeline →</Link>
        </Card>
      </div>
    </div>
  );
}
