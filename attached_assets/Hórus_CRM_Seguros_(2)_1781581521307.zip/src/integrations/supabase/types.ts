export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      admin_action_log: {
        Row: {
          action: string
          admin_id: string
          created_at: string
          id: string
          target: string | null
        }
        Insert: {
          action: string
          admin_id: string
          created_at?: string
          id?: string
          target?: string | null
        }
        Update: {
          action?: string
          admin_id?: string
          created_at?: string
          id?: string
          target?: string | null
        }
        Relationships: []
      }
      anexos: {
        Row: {
          criado_em: string
          entidade: Database["public"]["Enums"]["entidade_anexo"]
          entidade_id: string
          id: string
          mime: string | null
          nome: string
          owner_id: string
          storage_path: string
          tamanho: number | null
        }
        Insert: {
          criado_em?: string
          entidade: Database["public"]["Enums"]["entidade_anexo"]
          entidade_id: string
          id?: string
          mime?: string | null
          nome: string
          owner_id: string
          storage_path: string
          tamanho?: number | null
        }
        Update: {
          criado_em?: string
          entidade?: Database["public"]["Enums"]["entidade_anexo"]
          entidade_id?: string
          id?: string
          mime?: string | null
          nome?: string
          owner_id?: string
          storage_path?: string
          tamanho?: number | null
        }
        Relationships: []
      }
      apolices: {
        Row: {
          cliente_id: string | null
          comissao_pct: number
          criado_em: string
          fim: string | null
          id: string
          inicio: string | null
          numero: string
          observacao: string | null
          owner_id: string
          premio: number
          ramo: Database["public"]["Enums"]["ramo_seguro"]
          seguradora: string | null
          status: Database["public"]["Enums"]["status_apolice"]
        }
        Insert: {
          cliente_id?: string | null
          comissao_pct?: number
          criado_em?: string
          fim?: string | null
          id?: string
          inicio?: string | null
          numero: string
          observacao?: string | null
          owner_id: string
          premio?: number
          ramo?: Database["public"]["Enums"]["ramo_seguro"]
          seguradora?: string | null
          status?: Database["public"]["Enums"]["status_apolice"]
        }
        Update: {
          cliente_id?: string | null
          comissao_pct?: number
          criado_em?: string
          fim?: string | null
          id?: string
          inicio?: string | null
          numero?: string
          observacao?: string | null
          owner_id?: string
          premio?: number
          ramo?: Database["public"]["Enums"]["ramo_seguro"]
          seguradora?: string | null
          status?: Database["public"]["Enums"]["status_apolice"]
        }
        Relationships: [
          {
            foreignKeyName: "apolices_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
        ]
      }
      clientes: {
        Row: {
          cep: string | null
          cidade: string | null
          complemento: string | null
          contato_recado: string | null
          cpf_cnpj: string | null
          criado_em: string
          data_nascimento: string | null
          email: string | null
          endereco: string | null
          estado_civil: string | null
          id: string
          inscricao_estadual: string | null
          inscricao_municipal: string | null
          nome: string
          nome_fantasia: string | null
          numero: string | null
          observacao: string | null
          owner_id: string
          produto_categoria:
            | Database["public"]["Enums"]["produto_categoria"]
            | null
          produto_data_assembleia: string | null
          produto_id: string | null
          produto_qtd_parcelas: number | null
          produto_resultado_assembleia: string | null
          produto_valor_comissao: number | null
          produto_valor_contratado: number | null
          produto_valor_parcela: number | null
          produto_valor_total_parcelas: number | null
          razao_social: string | null
          rep_cpf: string | null
          rep_data_nascimento: string | null
          rep_nome: string | null
          rep_telefone: string | null
          telefone: string | null
          telefone_comercial: string | null
          tipo: Database["public"]["Enums"]["tipo_cliente"]
        }
        Insert: {
          cep?: string | null
          cidade?: string | null
          complemento?: string | null
          contato_recado?: string | null
          cpf_cnpj?: string | null
          criado_em?: string
          data_nascimento?: string | null
          email?: string | null
          endereco?: string | null
          estado_civil?: string | null
          id?: string
          inscricao_estadual?: string | null
          inscricao_municipal?: string | null
          nome: string
          nome_fantasia?: string | null
          numero?: string | null
          observacao?: string | null
          owner_id: string
          produto_categoria?:
            | Database["public"]["Enums"]["produto_categoria"]
            | null
          produto_data_assembleia?: string | null
          produto_id?: string | null
          produto_qtd_parcelas?: number | null
          produto_resultado_assembleia?: string | null
          produto_valor_comissao?: number | null
          produto_valor_contratado?: number | null
          produto_valor_parcela?: number | null
          produto_valor_total_parcelas?: number | null
          razao_social?: string | null
          rep_cpf?: string | null
          rep_data_nascimento?: string | null
          rep_nome?: string | null
          rep_telefone?: string | null
          telefone?: string | null
          telefone_comercial?: string | null
          tipo?: Database["public"]["Enums"]["tipo_cliente"]
        }
        Update: {
          cep?: string | null
          cidade?: string | null
          complemento?: string | null
          contato_recado?: string | null
          cpf_cnpj?: string | null
          criado_em?: string
          data_nascimento?: string | null
          email?: string | null
          endereco?: string | null
          estado_civil?: string | null
          id?: string
          inscricao_estadual?: string | null
          inscricao_municipal?: string | null
          nome?: string
          nome_fantasia?: string | null
          numero?: string | null
          observacao?: string | null
          owner_id?: string
          produto_categoria?:
            | Database["public"]["Enums"]["produto_categoria"]
            | null
          produto_data_assembleia?: string | null
          produto_id?: string | null
          produto_qtd_parcelas?: number | null
          produto_resultado_assembleia?: string | null
          produto_valor_comissao?: number | null
          produto_valor_contratado?: number | null
          produto_valor_parcela?: number | null
          produto_valor_total_parcelas?: number | null
          razao_social?: string | null
          rep_cpf?: string | null
          rep_data_nascimento?: string | null
          rep_nome?: string | null
          rep_telefone?: string | null
          telefone?: string | null
          telefone_comercial?: string | null
          tipo?: Database["public"]["Enums"]["tipo_cliente"]
        }
        Relationships: [
          {
            foreignKeyName: "clientes_produto_id_fkey"
            columns: ["produto_id"]
            isOneToOne: false
            referencedRelation: "produtos"
            referencedColumns: ["id"]
          },
        ]
      }
      comissoes: {
        Row: {
          apolice_id: string | null
          criado_em: string
          id: string
          owner_id: string
          parcela: number
          status: Database["public"]["Enums"]["status_comissao"]
          total_parcelas: number
          valor: number
          vencimento: string | null
        }
        Insert: {
          apolice_id?: string | null
          criado_em?: string
          id?: string
          owner_id: string
          parcela?: number
          status?: Database["public"]["Enums"]["status_comissao"]
          total_parcelas?: number
          valor?: number
          vencimento?: string | null
        }
        Update: {
          apolice_id?: string | null
          criado_em?: string
          id?: string
          owner_id?: string
          parcela?: number
          status?: Database["public"]["Enums"]["status_comissao"]
          total_parcelas?: number
          valor?: number
          vencimento?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "comissoes_apolice_id_fkey"
            columns: ["apolice_id"]
            isOneToOne: false
            referencedRelation: "apolices"
            referencedColumns: ["id"]
          },
        ]
      }
      consorcios: {
        Row: {
          administradora: string | null
          bem: string | null
          cliente_id: string | null
          cota: string | null
          criado_em: string
          grupo: string | null
          id: string
          inicio: string | null
          observacao: string | null
          owner_id: string
          parcela: number
          prazo_meses: number
          status: Database["public"]["Enums"]["status_consorcio"]
          taxa_adm_pct: number
          valor_credito: number
        }
        Insert: {
          administradora?: string | null
          bem?: string | null
          cliente_id?: string | null
          cota?: string | null
          criado_em?: string
          grupo?: string | null
          id?: string
          inicio?: string | null
          observacao?: string | null
          owner_id: string
          parcela?: number
          prazo_meses?: number
          status?: Database["public"]["Enums"]["status_consorcio"]
          taxa_adm_pct?: number
          valor_credito?: number
        }
        Update: {
          administradora?: string | null
          bem?: string | null
          cliente_id?: string | null
          cota?: string | null
          criado_em?: string
          grupo?: string | null
          id?: string
          inicio?: string | null
          observacao?: string | null
          owner_id?: string
          parcela?: number
          prazo_meses?: number
          status?: Database["public"]["Enums"]["status_consorcio"]
          taxa_adm_pct?: number
          valor_credito?: number
        }
        Relationships: [
          {
            foreignKeyName: "consorcios_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
        ]
      }
      oportunidades: {
        Row: {
          cliente: string
          criado_em: string
          estagio: Database["public"]["Enums"]["estagio_pipeline"]
          id: string
          observacao: string | null
          owner_id: string
          ramo: Database["public"]["Enums"]["ramo_seguro"]
          responsavel: string | null
          valor_estimado: number
        }
        Insert: {
          cliente: string
          criado_em?: string
          estagio?: Database["public"]["Enums"]["estagio_pipeline"]
          id?: string
          observacao?: string | null
          owner_id: string
          ramo?: Database["public"]["Enums"]["ramo_seguro"]
          responsavel?: string | null
          valor_estimado?: number
        }
        Update: {
          cliente?: string
          criado_em?: string
          estagio?: Database["public"]["Enums"]["estagio_pipeline"]
          id?: string
          observacao?: string | null
          owner_id?: string
          ramo?: Database["public"]["Enums"]["ramo_seguro"]
          responsavel?: string | null
          valor_estimado?: number
        }
        Relationships: []
      }
      produtos: {
        Row: {
          ativo: boolean
          categoria: Database["public"]["Enums"]["produto_categoria"]
          criado_em: string
          id: string
          nome: string
          tipo_pessoa: Database["public"]["Enums"]["produto_pessoa"]
        }
        Insert: {
          ativo?: boolean
          categoria: Database["public"]["Enums"]["produto_categoria"]
          criado_em?: string
          id?: string
          nome: string
          tipo_pessoa?: Database["public"]["Enums"]["produto_pessoa"]
        }
        Update: {
          ativo?: boolean
          categoria?: Database["public"]["Enums"]["produto_categoria"]
          criado_em?: string
          id?: string
          nome?: string
          tipo_pessoa?: Database["public"]["Enums"]["produto_pessoa"]
        }
        Relationships: []
      }
      profiles: {
        Row: {
          criado_em: string
          email: string | null
          id: string
          nome: string | null
        }
        Insert: {
          criado_em?: string
          email?: string | null
          id: string
          nome?: string | null
        }
        Update: {
          criado_em?: string
          email?: string | null
          id?: string
          nome?: string | null
        }
        Relationships: []
      }
      reunioes: {
        Row: {
          atualizado_em: string
          cliente_id: string | null
          criado_em: string
          data_hora: string
          enviar_convite: boolean
          id: string
          link_reuniao: string | null
          modalidade: string
          notificar_celular: boolean
          observacoes: string | null
          owner_id: string
          tipo: string
          titulo: string
        }
        Insert: {
          atualizado_em?: string
          cliente_id?: string | null
          criado_em?: string
          data_hora: string
          enviar_convite?: boolean
          id?: string
          link_reuniao?: string | null
          modalidade: string
          notificar_celular?: boolean
          observacoes?: string | null
          owner_id: string
          tipo: string
          titulo: string
        }
        Update: {
          atualizado_em?: string
          cliente_id?: string | null
          criado_em?: string
          data_hora?: string
          enviar_convite?: boolean
          id?: string
          link_reuniao?: string | null
          modalidade?: string
          notificar_celular?: boolean
          observacoes?: string | null
          owner_id?: string
          tipo?: string
          titulo?: string
        }
        Relationships: [
          {
            foreignKeyName: "reunioes_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
        ]
      }
      sinistros: {
        Row: {
          aberto_em: string
          apolice_id: string | null
          criado_em: string
          data_ocorrencia: string | null
          descricao: string | null
          id: string
          owner_id: string
          protocolo: string
          status: Database["public"]["Enums"]["status_sinistro"]
          valor_estimado: number
        }
        Insert: {
          aberto_em?: string
          apolice_id?: string | null
          criado_em?: string
          data_ocorrencia?: string | null
          descricao?: string | null
          id?: string
          owner_id: string
          protocolo: string
          status?: Database["public"]["Enums"]["status_sinistro"]
          valor_estimado?: number
        }
        Update: {
          aberto_em?: string
          apolice_id?: string | null
          criado_em?: string
          data_ocorrencia?: string | null
          descricao?: string | null
          id?: string
          owner_id?: string
          protocolo?: string
          status?: Database["public"]["Enums"]["status_sinistro"]
          valor_estimado?: number
        }
        Relationships: [
          {
            foreignKeyName: "sinistros_apolice_id_fkey"
            columns: ["apolice_id"]
            isOneToOne: false
            referencedRelation: "apolices"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      can_manage_seguros: { Args: { _uid: string }; Returns: boolean }
      check_admin_rate_limit: {
        Args: {
          _action: string
          _admin: string
          _limit: number
          _target: string
          _window: string
        }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: { Args: { _uid: string }; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "user" | "corretor" | "atendente"
      entidade_anexo: "cliente" | "apolice" | "consorcio" | "sinistro"
      estagio_pipeline:
        | "Lead"
        | "Cotação"
        | "Proposta"
        | "Negociação"
        | "Ganho"
        | "Perdido"
      produto_categoria: "seguro" | "consorcio"
      produto_pessoa: "PF" | "PJ" | "AMBOS"
      ramo_seguro:
        | "Auto"
        | "Vida"
        | "Residencial"
        | "Empresarial"
        | "Saúde"
        | "Viagem"
      status_apolice: "Vigente" | "A Renovar" | "Vencida" | "Cancelada"
      status_comissao: "A Receber" | "Recebida" | "Atrasada"
      status_consorcio:
        | "Ativo"
        | "Contemplado"
        | "Quitado"
        | "Cancelado"
        | "Atrasado"
      status_sinistro: "Aberto" | "Em Análise" | "Aprovado" | "Negado" | "Pago"
      tipo_cliente: "PF" | "PJ"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user", "corretor", "atendente"],
      entidade_anexo: ["cliente", "apolice", "consorcio", "sinistro"],
      estagio_pipeline: [
        "Lead",
        "Cotação",
        "Proposta",
        "Negociação",
        "Ganho",
        "Perdido",
      ],
      produto_categoria: ["seguro", "consorcio"],
      produto_pessoa: ["PF", "PJ", "AMBOS"],
      ramo_seguro: [
        "Auto",
        "Vida",
        "Residencial",
        "Empresarial",
        "Saúde",
        "Viagem",
      ],
      status_apolice: ["Vigente", "A Renovar", "Vencida", "Cancelada"],
      status_comissao: ["A Receber", "Recebida", "Atrasada"],
      status_consorcio: [
        "Ativo",
        "Contemplado",
        "Quitado",
        "Cancelado",
        "Atrasado",
      ],
      status_sinistro: ["Aberto", "Em Análise", "Aprovado", "Negado", "Pago"],
      tipo_cliente: ["PF", "PJ"],
    },
  },
} as const
