REVOKE EXECUTE ON FUNCTION public.can_manage_seguros(uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.is_admin(uuid) FROM PUBLIC, anon;