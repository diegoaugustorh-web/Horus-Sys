
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'corretor';
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'atendente';
