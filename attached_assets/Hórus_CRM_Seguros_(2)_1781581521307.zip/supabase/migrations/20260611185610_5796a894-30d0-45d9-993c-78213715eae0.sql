
-- =========== ENUMS ===========
CREATE TYPE public.app_role AS ENUM ('admin', 'user');
CREATE TYPE public.tipo_cliente AS ENUM ('PF','PJ');
CREATE TYPE public.ramo_seguro AS ENUM ('Auto','Vida','Residencial','Empresarial','Saúde','Viagem');
CREATE TYPE public.status_apolice AS ENUM ('Vigente','A Renovar','Vencida','Cancelada');
CREATE TYPE public.estagio_pipeline AS ENUM ('Lead','Cotação','Proposta','Negociação','Ganho','Perdido');
CREATE TYPE public.status_sinistro AS ENUM ('Aberto','Em Análise','Aprovado','Negado','Pago');
CREATE TYPE public.status_comissao AS ENUM ('A Receber','Recebida','Atrasada');
CREATE TYPE public.status_consorcio AS ENUM ('Ativo','Contemplado','Quitado','Cancelado','Atrasado');
CREATE TYPE public.entidade_anexo AS ENUM ('cliente','apolice','consorcio','sinistro');

-- =========== PROFILES ===========
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  nome TEXT,
  email TEXT,
  criado_em TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- =========== USER ROLES ===========
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  role app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

-- =========== SIGNUP TRIGGER (cria profile + role) ===========
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  _is_first BOOLEAN;
BEGIN
  INSERT INTO public.profiles (id, nome, email)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'nome', split_part(NEW.email,'@',1)), NEW.email);

  SELECT NOT EXISTS (SELECT 1 FROM public.user_roles) INTO _is_first;
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, CASE WHEN _is_first THEN 'admin'::app_role ELSE 'user'::app_role END);

  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- =========== POLICIES profiles/user_roles ===========
CREATE POLICY "profiles self read" ON public.profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "profiles self update" ON public.profiles FOR UPDATE TO authenticated
  USING (id = auth.uid() OR public.has_role(auth.uid(),'admin'));

CREATE POLICY "roles read self or admin" ON public.user_roles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));

-- =========== TABELAS DE NEGÓCIO ===========
CREATE TABLE public.clientes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  nome TEXT NOT NULL,
  cpf_cnpj TEXT,
  email TEXT,
  telefone TEXT,
  tipo tipo_cliente NOT NULL DEFAULT 'PF',
  cidade TEXT,
  observacao TEXT,
  criado_em TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.apolices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  cliente_id UUID REFERENCES public.clientes(id) ON DELETE SET NULL,
  numero TEXT NOT NULL,
  seguradora TEXT,
  ramo ramo_seguro NOT NULL DEFAULT 'Auto',
  premio NUMERIC(14,2) NOT NULL DEFAULT 0,
  inicio DATE,
  fim DATE,
  status status_apolice NOT NULL DEFAULT 'Vigente',
  comissao_pct NUMERIC(6,2) NOT NULL DEFAULT 0,
  observacao TEXT,
  criado_em TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.oportunidades (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  cliente TEXT NOT NULL,
  ramo ramo_seguro NOT NULL DEFAULT 'Auto',
  valor_estimado NUMERIC(14,2) NOT NULL DEFAULT 0,
  estagio estagio_pipeline NOT NULL DEFAULT 'Lead',
  responsavel TEXT,
  observacao TEXT,
  criado_em TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.sinistros (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  apolice_id UUID REFERENCES public.apolices(id) ON DELETE SET NULL,
  protocolo TEXT NOT NULL,
  data_ocorrencia DATE,
  descricao TEXT,
  valor_estimado NUMERIC(14,2) NOT NULL DEFAULT 0,
  status status_sinistro NOT NULL DEFAULT 'Aberto',
  aberto_em DATE NOT NULL DEFAULT CURRENT_DATE,
  criado_em TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.comissoes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  apolice_id UUID REFERENCES public.apolices(id) ON DELETE SET NULL,
  parcela INTEGER NOT NULL DEFAULT 1,
  total_parcelas INTEGER NOT NULL DEFAULT 1,
  valor NUMERIC(14,2) NOT NULL DEFAULT 0,
  vencimento DATE,
  status status_comissao NOT NULL DEFAULT 'A Receber',
  criado_em TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.consorcios (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  cliente_id UUID REFERENCES public.clientes(id) ON DELETE SET NULL,
  administradora TEXT,
  bem TEXT,
  grupo TEXT,
  cota TEXT,
  valor_credito NUMERIC(14,2) NOT NULL DEFAULT 0,
  prazo_meses INTEGER NOT NULL DEFAULT 0,
  taxa_adm_pct NUMERIC(6,2) NOT NULL DEFAULT 0,
  parcela NUMERIC(14,2) NOT NULL DEFAULT 0,
  inicio DATE,
  status status_consorcio NOT NULL DEFAULT 'Ativo',
  observacao TEXT,
  criado_em TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.anexos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  entidade entidade_anexo NOT NULL,
  entidade_id UUID NOT NULL,
  nome TEXT NOT NULL,
  mime TEXT,
  tamanho BIGINT,
  storage_path TEXT NOT NULL,
  criado_em TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_anexos_entidade ON public.anexos(entidade, entidade_id);

-- =========== GRANTS ===========
GRANT SELECT, INSERT, UPDATE, DELETE ON public.clientes TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.apolices TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.oportunidades TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.sinistros TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.comissoes TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.consorcios TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.anexos TO authenticated;
GRANT ALL ON public.clientes, public.apolices, public.oportunidades, public.sinistros, public.comissoes, public.consorcios, public.anexos TO service_role;

ALTER TABLE public.clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.apolices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.oportunidades ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sinistros ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comissoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.consorcios ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.anexos ENABLE ROW LEVEL SECURITY;

-- =========== RLS POLICIES (padrão owner_or_admin) ===========
DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['clientes','apolices','oportunidades','sinistros','comissoes','consorcios','anexos']
  LOOP
    EXECUTE format('CREATE POLICY %I ON public.%I FOR SELECT TO authenticated USING (owner_id = auth.uid() OR public.has_role(auth.uid(),''admin''))', t||'_select', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid() OR public.has_role(auth.uid(),''admin''))', t||'_insert', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR UPDATE TO authenticated USING (owner_id = auth.uid() OR public.has_role(auth.uid(),''admin'')) WITH CHECK (owner_id = auth.uid() OR public.has_role(auth.uid(),''admin''))', t||'_update', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR DELETE TO authenticated USING (owner_id = auth.uid() OR public.has_role(auth.uid(),''admin''))', t||'_delete', t);
  END LOOP;
END $$;
