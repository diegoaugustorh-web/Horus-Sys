CREATE TABLE public.reunioes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  cliente_id uuid REFERENCES public.clientes(id) ON DELETE SET NULL,
  titulo text NOT NULL CHECK (char_length(titulo) BETWEEN 1 AND 200),
  data_hora timestamptz NOT NULL,
  tipo text NOT NULL CHECK (tipo IN ('Reunião', 'Ligação', 'Apresentação', 'Follow-up')),
  modalidade text NOT NULL CHECK (modalidade IN ('Presencial', 'Microsoft Teams', 'Google Meet', 'Telefone')),
  link_reuniao text CHECK (link_reuniao IS NULL OR char_length(link_reuniao) <= 1000),
  enviar_convite boolean NOT NULL DEFAULT true,
  notificar_celular boolean NOT NULL DEFAULT false,
  observacoes text CHECK (observacoes IS NULL OR char_length(observacoes) <= 5000),
  criado_em timestamptz NOT NULL DEFAULT now(),
  atualizado_em timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.reunioes TO authenticated;
GRANT ALL ON public.reunioes TO service_role;

ALTER TABLE public.reunioes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Usuários visualizam reuniões permitidas"
ON public.reunioes FOR SELECT TO authenticated
USING (owner_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Usuários criam as próprias reuniões"
ON public.reunioes FOR INSERT TO authenticated
WITH CHECK (owner_id = auth.uid());

CREATE POLICY "Usuários alteram reuniões permitidas"
ON public.reunioes FOR UPDATE TO authenticated
USING (owner_id = auth.uid() OR public.has_role(auth.uid(), 'admin'))
WITH CHECK (owner_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Usuários removem reuniões permitidas"
ON public.reunioes FOR DELETE TO authenticated
USING (owner_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE INDEX reunioes_owner_data_idx ON public.reunioes (owner_id, data_hora);
CREATE INDEX reunioes_cliente_idx ON public.reunioes (cliente_id);

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS trigger
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
BEGIN
  NEW.atualizado_em = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_reunioes_atualizado_em
BEFORE UPDATE ON public.reunioes
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();