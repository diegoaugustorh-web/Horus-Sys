-- Add structured product interest fields to clientes
ALTER TABLE public.clientes
  ADD COLUMN IF NOT EXISTS produto_id uuid REFERENCES public.produtos(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS produto_categoria public.produto_categoria,
  ADD COLUMN IF NOT EXISTS produto_valor_contratado numeric(14,2),
  ADD COLUMN IF NOT EXISTS produto_qtd_parcelas integer,
  ADD COLUMN IF NOT EXISTS produto_valor_parcela numeric(14,2),
  ADD COLUMN IF NOT EXISTS produto_valor_total_parcelas numeric(14,2),
  ADD COLUMN IF NOT EXISTS produto_valor_comissao numeric(14,2),
  ADD COLUMN IF NOT EXISTS produto_data_assembleia date,
  ADD COLUMN IF NOT EXISTS produto_resultado_assembleia text;

-- Sanity: non-negative numbers and parcelas >= 0
ALTER TABLE public.clientes
  DROP CONSTRAINT IF EXISTS clientes_produto_valores_chk;
ALTER TABLE public.clientes
  ADD CONSTRAINT clientes_produto_valores_chk CHECK (
    (produto_valor_contratado IS NULL OR produto_valor_contratado >= 0)
    AND (produto_valor_parcela IS NULL OR produto_valor_parcela >= 0)
    AND (produto_valor_total_parcelas IS NULL OR produto_valor_total_parcelas >= 0)
    AND (produto_valor_comissao IS NULL OR produto_valor_comissao >= 0)
    AND (produto_qtd_parcelas IS NULL OR produto_qtd_parcelas >= 0)
  );

-- Assembleia só faz sentido para consórcio
ALTER TABLE public.clientes
  DROP CONSTRAINT IF EXISTS clientes_produto_assembleia_chk;
ALTER TABLE public.clientes
  ADD CONSTRAINT clientes_produto_assembleia_chk CHECK (
    produto_categoria = 'consorcio'
    OR (produto_data_assembleia IS NULL AND produto_resultado_assembleia IS NULL)
  );

CREATE INDEX IF NOT EXISTS clientes_produto_id_idx ON public.clientes(produto_id);
CREATE INDEX IF NOT EXISTS clientes_produto_categoria_idx ON public.clientes(produto_categoria);