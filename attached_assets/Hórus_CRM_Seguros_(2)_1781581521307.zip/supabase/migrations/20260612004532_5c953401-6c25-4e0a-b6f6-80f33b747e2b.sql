
-- Funções auxiliares de permissão
CREATE OR REPLACE FUNCTION public.is_admin(_uid uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS(SELECT 1 FROM public.user_roles WHERE user_id = _uid AND role::text = 'admin');
$$;

CREATE OR REPLACE FUNCTION public.can_manage_seguros(_uid uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS(SELECT 1 FROM public.user_roles WHERE user_id = _uid AND role::text IN ('admin','corretor'));
$$;

-- Converter perfis legados 'user' em 'corretor'
UPDATE public.user_roles SET role = 'corretor'::public.app_role WHERE role::text = 'user';

-- Novo padrão de signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _is_first BOOLEAN;
BEGIN
  INSERT INTO public.profiles (id, nome, email)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'nome', split_part(NEW.email,'@',1)), NEW.email);

  SELECT NOT EXISTS (SELECT 1 FROM public.user_roles) INTO _is_first;
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, CASE WHEN _is_first THEN 'admin'::public.app_role ELSE 'corretor'::public.app_role END);

  RETURN NEW;
END;
$$;

-- user_roles: somente admin gerencia
DROP POLICY IF EXISTS "roles admin manage insert" ON public.user_roles;
DROP POLICY IF EXISTS "roles admin manage update" ON public.user_roles;
DROP POLICY IF EXISTS "roles admin manage delete" ON public.user_roles;
CREATE POLICY "roles admin manage insert" ON public.user_roles FOR INSERT TO authenticated
  WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "roles admin manage update" ON public.user_roles FOR UPDATE TO authenticated
  USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "roles admin manage delete" ON public.user_roles FOR DELETE TO authenticated
  USING (public.is_admin(auth.uid()));

-- APÓLICES
DROP POLICY IF EXISTS "apolices_insert" ON public.apolices;
DROP POLICY IF EXISTS "apolices_update" ON public.apolices;
DROP POLICY IF EXISTS "apolices_delete" ON public.apolices;
CREATE POLICY "apolices_insert" ON public.apolices FOR INSERT TO authenticated
  WITH CHECK ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()));
CREATE POLICY "apolices_update" ON public.apolices FOR UPDATE TO authenticated
  USING ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()))
  WITH CHECK ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()));
CREATE POLICY "apolices_delete" ON public.apolices FOR DELETE TO authenticated
  USING ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()));

-- SINISTROS
DROP POLICY IF EXISTS "sinistros_insert" ON public.sinistros;
DROP POLICY IF EXISTS "sinistros_update" ON public.sinistros;
DROP POLICY IF EXISTS "sinistros_delete" ON public.sinistros;
CREATE POLICY "sinistros_insert" ON public.sinistros FOR INSERT TO authenticated
  WITH CHECK ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()));
CREATE POLICY "sinistros_update" ON public.sinistros FOR UPDATE TO authenticated
  USING ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()))
  WITH CHECK ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()));
CREATE POLICY "sinistros_delete" ON public.sinistros FOR DELETE TO authenticated
  USING ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()));

-- CONSÓRCIOS
DROP POLICY IF EXISTS "consorcios_insert" ON public.consorcios;
DROP POLICY IF EXISTS "consorcios_update" ON public.consorcios;
DROP POLICY IF EXISTS "consorcios_delete" ON public.consorcios;
CREATE POLICY "consorcios_insert" ON public.consorcios FOR INSERT TO authenticated
  WITH CHECK ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()));
CREATE POLICY "consorcios_update" ON public.consorcios FOR UPDATE TO authenticated
  USING ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()))
  WITH CHECK ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()));
CREATE POLICY "consorcios_delete" ON public.consorcios FOR DELETE TO authenticated
  USING ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()));

-- COMISSÕES
DROP POLICY IF EXISTS "comissoes_insert" ON public.comissoes;
DROP POLICY IF EXISTS "comissoes_update" ON public.comissoes;
DROP POLICY IF EXISTS "comissoes_delete" ON public.comissoes;
CREATE POLICY "comissoes_insert" ON public.comissoes FOR INSERT TO authenticated
  WITH CHECK ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()));
CREATE POLICY "comissoes_update" ON public.comissoes FOR UPDATE TO authenticated
  USING ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()))
  WITH CHECK ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()));
CREATE POLICY "comissoes_delete" ON public.comissoes FOR DELETE TO authenticated
  USING ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()));

-- CLIENTES / OPORTUNIDADES: atendente cria/edita, mas não remove
DROP POLICY IF EXISTS "clientes_delete" ON public.clientes;
CREATE POLICY "clientes_delete" ON public.clientes FOR DELETE TO authenticated
  USING ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "oportunidades_delete" ON public.oportunidades;
CREATE POLICY "oportunidades_delete" ON public.oportunidades FOR DELETE TO authenticated
  USING ((owner_id = auth.uid() AND public.can_manage_seguros(auth.uid())) OR public.is_admin(auth.uid()));
