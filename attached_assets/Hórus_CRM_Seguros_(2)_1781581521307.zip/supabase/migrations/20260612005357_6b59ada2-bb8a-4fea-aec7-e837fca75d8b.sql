CREATE TABLE public.admin_action_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid NOT NULL,
  action text NOT NULL,
  target text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX admin_action_log_admin_action_time_idx
  ON public.admin_action_log (admin_id, action, created_at DESC);
CREATE INDEX admin_action_log_target_action_time_idx
  ON public.admin_action_log (target, action, created_at DESC);

GRANT SELECT ON public.admin_action_log TO authenticated;
GRANT ALL ON public.admin_action_log TO service_role;

ALTER TABLE public.admin_action_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view admin action log"
  ON public.admin_action_log FOR SELECT
  TO authenticated
  USING (public.is_admin(auth.uid()));

CREATE OR REPLACE FUNCTION public.check_admin_rate_limit(
  _admin uuid,
  _action text,
  _target text,
  _window interval,
  _limit int
) RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE((
    SELECT COUNT(*) FROM public.admin_action_log
    WHERE action = _action
      AND created_at > now() - _window
      AND (_admin IS NULL OR admin_id = _admin)
      AND (_target IS NULL OR target = _target)
  ), 0) < _limit;
$$;