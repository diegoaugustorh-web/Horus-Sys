
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;

CREATE POLICY "anexos_read" ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'anexos' AND (
    auth.uid()::text = (storage.foldername(name))[1]
    OR public.has_role(auth.uid(),'admin')
  )
);
CREATE POLICY "anexos_insert" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'anexos' AND auth.uid()::text = (storage.foldername(name))[1]
);
CREATE POLICY "anexos_delete" ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'anexos' AND (
    auth.uid()::text = (storage.foldername(name))[1]
    OR public.has_role(auth.uid(),'admin')
  )
);
