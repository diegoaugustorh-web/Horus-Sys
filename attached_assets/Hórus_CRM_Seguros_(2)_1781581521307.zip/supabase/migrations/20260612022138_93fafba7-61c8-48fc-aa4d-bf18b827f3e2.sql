-- 1) Expand clientes
ALTER TABLE public.clientes
  ADD COLUMN IF NOT EXISTS data_nascimento date,
  ADD COLUMN IF NOT EXISTS estado_civil text,
  ADD COLUMN IF NOT EXISTS contato_recado text,
  ADD COLUMN IF NOT EXISTS cep text,
  ADD COLUMN IF NOT EXISTS endereco text,
  ADD COLUMN IF NOT EXISTS numero text,
  ADD COLUMN IF NOT EXISTS complemento text,
  ADD COLUMN IF NOT EXISTS razao_social text,
  ADD COLUMN IF NOT EXISTS nome_fantasia text,
  ADD COLUMN IF NOT EXISTS inscricao_estadual text,
  ADD COLUMN IF NOT EXISTS inscricao_municipal text,
  ADD COLUMN IF NOT EXISTS telefone_comercial text,
  ADD COLUMN IF NOT EXISTS rep_nome text,
  ADD COLUMN IF NOT EXISTS rep_cpf text,
  ADD COLUMN IF NOT EXISTS rep_data_nascimento date,
  ADD COLUMN IF NOT EXISTS rep_telefone text;

-- 2) Produto catalog
DO $$ BEGIN
  CREATE TYPE public.produto_categoria AS ENUM ('seguro','consorcio');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.produto_pessoa AS ENUM ('PF','PJ','AMBOS');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.produtos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  categoria public.produto_categoria NOT NULL,
  tipo_pessoa public.produto_pessoa NOT NULL DEFAULT 'AMBOS',
  nome text NOT NULL,
  ativo boolean NOT NULL DEFAULT true,
  criado_em timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.produtos TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.produtos TO authenticated;
GRANT ALL ON public.produtos TO service_role;

ALTER TABLE public.produtos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "produtos_select" ON public.produtos
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "produtos_insert" ON public.produtos
  FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "produtos_update" ON public.produtos
  FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "produtos_delete" ON public.produtos
  FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'::public.app_role));

-- 3) Seed alguns produtos comuns
INSERT INTO public.produtos (categoria, tipo_pessoa, nome) VALUES
  ('seguro','PF','Seguro Auto'),
  ('seguro','PF','Seguro Vida'),
  ('seguro','PF','Seguro Residencial'),
  ('seguro','PF','Seguro Viagem'),
  ('seguro','PF','Seguro Saúde'),
  ('seguro','PJ','Seguro Empresarial'),
  ('seguro','PJ','Seguro Frota'),
  ('seguro','PJ','Seguro Responsabilidade Civil'),
  ('seguro','PJ','Seguro Vida em Grupo'),
  ('consorcio','PF','Consórcio Imóvel'),
  ('consorcio','PF','Consórcio Veículo'),
  ('consorcio','PF','Consórcio Motocicleta'),
  ('consorcio','PJ','Consórcio Imóvel Comercial'),
  ('consorcio','PJ','Consórcio Veículos Frota'),
  ('consorcio','PJ','Consórcio Equipamentos')
ON CONFLICT DO NOTHING;